# About

A wrapper around Nodemailer to send HTML emails

Uses [Pug](https://github.com/pugjs/pug) and [Nodemailer](https://github.com/nodemailer/nodemailer) to send HTML emails.

# Usage

1. **Install MailedIt**

   `$: npm i -S @skulpture/mailedit`

2. **Import the makeMailedIt function**

   `makeMailedIt` requires a configuration object which has the following interface:

   `{ template: string, details: SenderDetails }`

   `template` is the Pug template to use

   `details` is the details of the SMTP server

   `// In your TypeScript or JavaScript file`

   `import makeMailedIt from '@skulpture/mailedIt'`

   `const mailedIt = makeMailedIt(configuration)`

3. **Use the resulting MailedIt object**

   `mailedIt.post(envelope, transform)`

   `envelope` is the mail envelope you want to send

   `transform` an optional function to transform the data to the shape required for the Pug template

# Contribution

Contributions are welcome, just make a pull request
