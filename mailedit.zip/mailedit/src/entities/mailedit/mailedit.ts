import { readFile } from "fs/promises";

export interface MailedIt {
	/**
	 * Send an email
	 *
	 * @param {Envelope} envelope the envelope
	 * @param {DataTransformer} transform optional data transformer
	 * @returns {void}
	 */
	post: (envelope: Envelope, transform?: DataTransformer) => Promise<void>;
}

export interface Envelope {
	from: string;
	to: string;
	cc?: string;
	bcc?: string;
	replyTo?: string;
	subject: string;
	data: Record<string, any>;
	attachments?: Attachment | Attachment[];
}

export interface Attachment {
	/**
	 * The name of the file
	 */
	filename: string;

	/**
	 * The path to the file
	 */
	path: string;
}

interface MailerEnvelope {
	from: string;
	to: string;
	cc?: string;
	bcc?: string;
	replyTo?: string;
	subject: string;
	html: string;
	attachments?: Attachment[];
}

export interface MailedItConfiguration {
	template?: string;
	path?: string;
	details: SenderDetails;
}

export interface SenderDetails {
	host: string;
	port: number;
	secure: boolean;
	authentication: {
		username: string;
		password: string;
	};
	/**
	 * For some email address an MX registry lookup will no succeed
	 * In these cases you might want to turn host verification off
	 */
	skipHostVerification?: boolean;
}

export type DataTransformer = (
	data: Record<string, any>,
) => Record<string, any>;

export default function buildMakeMailedIt({
	Mailer,
	TemplatingEngine,
	MXRegistry,
}: {
	Mailer: Mailer;
	TemplatingEngine: TemplatingEngine;
	MXRegistry: MXRegistry;
}) {
	return function makeMailedIt(configuration: MailedItConfiguration): MailedIt {
		return Object.freeze({
			post: async (envelope: Envelope, transform?: DataTransformer) => {
				if (!configuration.details.skipHostVerification) {
					const isEmailValid = await MXRegistry.isDomainValid(envelope.to);

					if (!isEmailValid)
						throw new Error(`${envelope.to} is not a valid email address`);
				}

				let template: string | undefined;

				if (configuration.template) template = configuration.template;
				else if (configuration.path) {
					const buffer = await readFile(configuration.path);

					template = buffer.toString();
				}

				if (!template) throw new Error("Unable to load template");

				let templateData: Record<string, any> = envelope.data;
				if (transform !== undefined) templateData = transform(templateData);

				const html: string = await TemplatingEngine.compile(
					template,
					templateData,
				);

				let attachments: Attachment[] | undefined = undefined;
				if (envelope.attachments) {
					attachments = [];

					if (Array.isArray(envelope.attachments))
						attachments.push(...envelope.attachments);
					else attachments.push(envelope.attachments);
				}

				const mailerEnvelope = {
					from: envelope.from,
					to: envelope.to,
					cc: envelope?.cc,
					bcc: envelope?.bcc,
					replyTo: envelope?.replyTo,
					subject: envelope.subject,
					html,
					attachments,
				};

				return await Mailer.send(mailerEnvelope, configuration.details);
			},
		});
	};
}

export interface Mailer {
	/**
	 * Send an email using whichever mailer package is used
	 */
	send: (envelope: MailerEnvelope, details: SenderDetails) => Promise<void>;
}

export interface TemplatingEngine {
	/**
	 * Compile a HTML template
	 *
	 * @param {string} template the path to the HTML template
	 * @param {Record<string, any>} data the data to inject
	 * @param {Record<string, any>} configuration optional configuration
	 * @returns {string} the compiled HTML
	 */
	compile: (
		template: string,
		data: Record<string, any>,
		configuration?: Record<string, any>,
	) => Promise<string>;
}

export interface MXRegistry {
	/**
	 * Checks if the domain associated with an email address is valid
	 *
	 * @param {string} email the email address
	 * @returns {boolean}
	 */
	isDomainValid: (email: string) => Promise<boolean>;
}
