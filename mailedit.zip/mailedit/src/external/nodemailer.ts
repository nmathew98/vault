import nodemailer from "nodemailer";
import { Mailer } from "../entities/mailedit/mailedit";

const Nodemailer: Mailer = {
	async send(envelope, details) {
		const transporter = nodemailer.createTransport({
			host: details.host,
			port: details.port,
			secure: details.secure,
			auth: {
				user: details.authentication.username,
				pass: details.authentication.password,
			},
		});

		await transporter.sendMail({
			from: envelope.from,
			to: envelope.to,
			cc: envelope?.cc,
			bcc: envelope?.bcc,
			replyTo: envelope?.replyTo,
			subject: envelope.subject,
			html: envelope.html,
			attachments: envelope?.attachments,
		});
	},
};

export default Nodemailer;
