import { resolveMx } from "dns/promises";
import { MXRegistry } from "../entities/mailedit/mailedit";

const MXRegistry: MXRegistry = {
	isDomainValid: async (to: string) => {
		// RFC 5322 regex
		const emailRegex =
			/(?:[a-z0-9!#$%&'*+\/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+\/=?^_`{|}~-]+)*|"(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21\x23-\x5b\x5d-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])*")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21-\x5a\x53-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])+)\])/;

		if (emailRegex.test(to)) {
			const email = to.match(emailRegex)?.pop();

			if (!email)
				throw new Error(`${to} does not contain a valid email address`);

			const hostname = email.split("@").pop();
			if (!hostname || !hostname.length)
				throw new Error(`${email} is not a valid email address`);

			const mxRecords = await resolveMx(hostname);

			if (!mxRecords || !mxRecords.length) return false;

			return true;
		}

		return false;
	},
};

export default MXRegistry;
