import buildMakeMailedIt from "./entities/mailedit/mailedit";
import Nodemon from "./external/nodemailer";
import Pug from "./external/pug";
import MXRegistry from "./external/mx-registry";

export default buildMakeMailedIt({
	Mailer: Nodemon,
	TemplatingEngine: Pug,
	MXRegistry,
});

export { MailedIt, MailedItConfiguration } from "./entities/mailedit/mailedit";
