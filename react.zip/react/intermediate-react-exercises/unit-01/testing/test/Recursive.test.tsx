import { render, shallow } from "enzyme";
import { describe, expect, vi, it } from "vitest";

import { Recursive } from "../components/Recursive";

describe("Recursive", () => {
  const data = {
    title: "I",
    children: [
      {
        title: "am",
        children: [
          {
            title: "groot!!",
            children: null,
          },
        ],
      },
    ],
  };

  describe("checks the prop types", () => {
    it("`key` must be a string", () => {
      const spy = vi.spyOn(global.console, "error");

      shallow(<Recursive key={1} data={data} />);

      expect(spy).toBeCalledTimes(1);
    });

    it("`count` must be a react ref", () => {
      const spy = vi.spyOn(global.console, "error");

      shallow(<Recursive count={{}} data={data} />);

      expect(spy).toBeCalledTimes(1);
    });

    it("`data` must be a Tree", () => {
      const spy = vi.spyOn(global.console, "error");

      shallow(<Recursive data={{}} />);

      expect(spy).toBeCalledTimes(1);
    });
  });

  it("renders a tree", () => {
    expect(render(<Recursive data={data} />)).toMatchSnapshot();
  });
});
