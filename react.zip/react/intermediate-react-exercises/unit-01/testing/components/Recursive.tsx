import React from "react";
import PropTypes from "prop-types";

interface Tree {
  title: string;
  children: Tree[] | null;
  value?: string;
}

interface Props {
  count?: ReturnType<typeof React.useRef<number>>;
  key?: string;
  data: Tree;
}

export const Recursive = (props: Props) => {
  // CSS is a better way
  const count = props?.count ?? React.useRef(0);

  if (count.current) count.current++;

  return (
    <div>
      <span>
        {"&emsp;".repeat(count.current as number)}
        {props.data.title}
      </span>
      {!!props.data?.value && <span>{props.data?.value}</span>}
      {props.data.children?.map((child) => (
        <Recursive count={count} key={child.title} data={child} />
      ))}
    </div>
  );
};

const isReactRef = (
  props: Record<string, any>,
  propName: string,
  componentName: string
) => {
  if (props[propName] && typeof props[propName]?.current !== typeof 0)
    return new Error(
      `Invalid prop ${propName} supplied to ${componentName}. It should be a React ref to a number.`
    );
};

const isTree = (
  props: Record<string, any>,
  propName: string,
  componentName: string
) => {
  if (!props[propName]?.title) {
    return new Error(
      `Invalid prop ${propName} supplied to ${componentName}. The title should be specified`
    );
  }

  if (
    typeof props[propName]?.children !== "object" &&
    typeof props[propName]?.children !== typeof null
  ) {
    return new Error(
      `Invalid prop ${propName} supplied to ${componentName}. Children should be null or an array`
    );
  }

  if (props[propName]?.value && typeof props[propName]?.value !== typeof "") {
    return new Error(
      `Invalid prop ${propName} supplied to ${componentName}. Value should be a string`
    );
  }
};

Recursive.propTypes = {
  count: isReactRef,
  key: PropTypes.string,
  data: isTree,
};

export function App(props: any) {
  const data = {
    title: "I",
    children: [
      {
        title: "am",
        children: [
          {
            title: "groot!!",
            children: null,
          },
        ],
      },
    ],
  };

  return <Recursive data={data} />;
}
