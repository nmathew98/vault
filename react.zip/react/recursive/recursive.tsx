import React from "react";

interface Tree {
  title: string;
  children: Tree[] | null;
  value?: string;
}

interface Props {
  count?: ReturnType<typeof React.useRef>;
  key?: string;
  data: Tree;
}

const Recursive = (props: Props) => {
  // CSS is a better way
  const count = props?.count ?? React.useRef(0);

  count.current++;

  return (
    <div>
      <span>
        {"&emsp;".repeat(count.current)}
        {props.data.title}
      </span>
      {!!props.data?.value && <span>{props.data?.value}</span>}
      {props.data.children?.map((child) => (
        <Recursive count={count} key={child.title} data={child} />
      ))}
    </div>
  );
};

export function App(props) {
  const data = {
    title: "I",
    children: [
      {
        title: "am",
        children: [
          {
            title: "groot!!",
            children: null,
          },
        ],
      },
    ],
  };

  return <Recursive data={data} />;
}
