import React from 'react'

export const slot = (Component) => ({ children, ...rest }) => {
  const childrenArray = React.Children.toArray(children)
  const slots = childrenArray.reduce(
    (children, child) => ({
      ...children,
      [child.props.name]: child
    }),
    Object.create(null)
  );

  return childrenArray.length > 0 && Component({ ...rest, ...slots })
};

const Test = ({ hello, world }) => {
  return <React.Fragment>
  	{hello}
  	{world}
  </React.Fragment>;
};
const SlotTest = slot(Test);

export function App(props) {
  return (
    <>
      <SlotTest>
        <div name="hello">Hello</div>
        <div name="world">World</div>
      </SlotTest>
    </>
  );
}