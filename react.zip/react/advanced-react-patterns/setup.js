require('./scripts/setup')

