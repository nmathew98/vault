module.exports = require('@kentcdodds/react-workshop-app/craco.config')
