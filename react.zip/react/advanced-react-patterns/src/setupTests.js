import '@kentcdodds/react-workshop-app/setup-tests'
