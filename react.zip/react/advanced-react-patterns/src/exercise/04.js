// Prop Collections and Getters
// http://localhost:3000/isolated/exercise/04.js

import * as React from 'react'
import {Switch} from '../switch'

const mergeReduce =
  (...mergers) =>
  (...o) =>
    mergers
      .reduce((merged, merger) => [merger(...merged, ...o)], [])
      .pop()

const composeFns = (...o) => {
  const merged = new Map()

  const createMultiFns = () => {
    const fns = []
    const x = () => fns.forEach(f => f())

    x.push = (...f) => fns.push(...f)

    return x
  }

  const merge = (merged, ...rest) => {
    for (const o of rest) {
      for (const [key, value] of Object.entries(o)) {
        if (merged.has(key)) {
          if (typeof value !== 'function') {
            merged.set(key, value)
            continue
          }

          const existing = merged.get(key)
          existing.push(value)
        } else {
          if (typeof value !== 'function') {
            merged.set(key, value)
            continue
          }

          const multi = createMultiFns()

          multi.push(value)
          merged.set(key, multi)
        }
      }
    }
  }

  merge(merged, ...o)

  return Object.fromEntries(merged)
}

function useToggle() {
  const [on, setOn] = React.useState(false)
  const toggle = () => setOn(!on)

  // 🐨 Add a property called `togglerProps`. It should be an object that has
  // `aria-pressed` and `onClick` properties.
  // 💰 {'aria-pressed': on, onClick: toggle}
  return {
    on,
    toggle,
    togglerProps: {
      'aria-pressed': on,
      onClick: toggle,
    },
  }
}

function App() {
  const {on, togglerProps} = useToggle()

  const buttonProps = {
    onClick: () => console.info('onButtonClick'),
  }

  const merge = mergeReduce(composeFns)

  return (
    <div>
      <Switch on={on} {...togglerProps} />
      <hr />
      <button
        aria-label="custom-button"
        {...merge(togglerProps, buttonProps)}
      >
        {on ? 'on' : 'off'}
      </button>
    </div>
  )
}

export default App

/*
eslint
  no-unused-vars: "off",
*/
