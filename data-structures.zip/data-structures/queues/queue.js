// In this exercise, you will build an example queue using a linked list with a
// reference to the tail. In this case, you will implement the methods of a
// queue.
class Queue {
  constructor() {
    this._head = null;
    this._tail = null;
    this.length = 0;
  }

  // The enqueue method will add an item to the internal linked list at the
  // tail. If this is the first time added, it needs to set the tail and the
  // head. Don't forget to update the length field.
  enqueue(value) {
    const newTail = {
      value,
      next: null
    };

    if (this.length == 0) {
      this._tail = newTail;
      this._head = newTail;
      this.length++;

      return;
    }

    const oldTail = this._tail;
    this._tail = newTail;

    const oldHead = this._head;
    const newHead = { ...oldHead };

    for (let i = newHead; i && (i.value || i.next); i = i.next) {
      if (!i.next) {
        i.next = newTail;
        break;
      }
    }

    this._head = newHead;
    this.length++;
  }

  // The peek method will return the first item's value in the queue, but it
  // does not remove it from the queue. It will return undefined if there are
  // no items in the queue.
  peek() {
    if (this.length === 0) return undefined;

    return this._head.value;
  }

  // The dequeue method will return the first item's value from the linked list
  // as well as remove it from the linked list. It will return undefined if
  // there are no items in the queue. Don't forget to update the length field.
  // Also, if the list is emptied, update the tail to be null as well.
  dequeue() {
    if (this.length === 0) return undefined;

    const initialHead = this._head;
    const newHead = this._head?.next ?? null;

    this._head = newHead;
    if (!newHead) {
      this._tail = null;
    }

    this.length--;

    return initialHead.value;
  }
}

module.exports = Queue;
