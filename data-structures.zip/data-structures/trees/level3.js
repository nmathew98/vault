// isBST
function isBST(tree) {

}
// isBalanced
