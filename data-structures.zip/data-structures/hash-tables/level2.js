'use strict';

/*

Create a function named reverseMerge.
It takes two arguments "keyArr" and "valArr" both of type Array.
It will return a hash that is a merge between the two inputs where
the values in keyArr will be the hashes key and
the values in valArr will be the hashes value.
The catch is that the values from the valArr will be assigned in from last to first.

i.e.
keyArr = [a, b, c];
valArr = [1, 2, 3];

output => {a: 3, b: 2, c: 1}

*/

const reverseMerge = (keyArr, valArr) => {
	const pairs = keyArr.map((key, index) => {
		if (keyArr.length >= valArr.length) {
			const value = valArr[keyArr.length - 1 - index];

			return [key, value ?? 42]			
		}

		if (valArr.length > keyArr.length) {
			const value = valArr[valArr.length - 1 - index];

			return [key, value ?? 42]
		}
	});

	if (valArr.length > keyArr.length) {
		pairs.push(["foo", valArr.reverse().slice(keyArr.length)]);
	}

	return Object.fromEntries(pairs);
}

/*

Create a function named mostUsedWord.
It takes a single argument "sentence" of type string.
It will return an object with a single key-value pair.
The key will be the word with the highest occurance in the string.
The value will the the number of occurances of that word in the string.

*/

const mostUsedWord = (sentence) => {
	const words = sentence.toLowerCase().split(" ");
	const map = new Map();

	words.forEach(word => {
		if (map.has(word)) {
			const occurence = map.get(word);

			map.set(word, occurence + 1);
		} else {
			map.set(word, 1);
		}
	});

	let highestValuePair = [null, -1];

	for (const [key, value] of map) {
		if (value > highestValuePair[1]) {
			highestValuePair = [key, value]
		}
	}

	return Object.fromEntries([highestValuePair]);
}


/*

Write a function, isAnagram.
It takes a two arguments "test" and "original", both of type string.
It returns TRUE if the words are anagrams of one another and FALSE if it is not.

*/

const isAnagram = (test, original) => {
	const normalizedTest = test.toLowerCase().split("");
	const normalizedOriginal = original.toLowerCase().split("");
	
	const lettersInTest = new Set(normalizedTest);
	const lettersInOriginal = new Set(normalizedOriginal);
	const combined = new Set(normalizedTest.concat(normalizedOriginal));

	return combined.size === lettersInTest.size && combined.size === lettersInOriginal.size;
}

module.exports = { reverseMerge, mostUsedWord, isAnagram };
