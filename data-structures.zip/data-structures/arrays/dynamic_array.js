const FixedArray = require('./fixed_array');

class DynamicArray {
  constructor(length) {
    this.length = length;

    // Initialize the array for twice the length
    this.array = new FixedArray(length * 2);
  }

  get(index) {
    if (index < 0 || index >= this.length) {
      throw new Error('Index out of bounds');
    }

    return this.array.get(index);
  }

  set(index, item) {
    if (index < 0 || index >= this.length) {
      throw new Error('Index out of bounds');
    }

    this.array.set(index, item);
  }

  // Implement a method push that takes in one argument, item (a number), it
  // adds the item to the end of the array, copying it to a new FixedArray if
  // necessary. There is no need to return anything.
  push(item) {
    const lastItem = this.get(this.length - 1);

    if (lastItem) {
      const newArray = new FixedArray(this.length + 1);

      this.resize(this.length + 1, this.length + 1);
    }

    this.set(this.length - 1, item);
  }

  // Implement a method pop that does not take in any arguments. It delete the
  // item at the end of the array.
  pop() {
    this.del(this.length - 1);
  }

  // Implement a method del that takes in one argument, index (a number), it
  // deletes the item at that index. There is no need to return anything.
  del(index) {
    if (index < 0 || index >= this.length) {
      throw new Error('Index out of bounds');
    }

    const newLength = this.length - 1;

    this.resize(newLength, newLength * 2, currentIndex => {
      if (currentIndex === index) {
        return null;
      }

      return currentIndex < index ? currentIndex : currentIndex - 1;
    });
  }

  resize(length, fixedArrayLength, callback) {
    const newArray = new FixedArray(fixedArrayLength);

    for (let i = 0; i < this.length; i++) {
      if (!callback) {
        newArray.set(i, this.get(i));
        
        continue;
      }

      const newIndex = callback(i);

      if (newIndex === null || newIndex === undefined) continue;

      newArray.set(newIndex, this.get(i));
    }

    this.array = newArray;
    this.length = length;
  }
}

module.exports = DynamicArray;
