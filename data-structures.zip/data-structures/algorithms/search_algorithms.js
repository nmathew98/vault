'use strict'

const linearSearch = function(array, value) {
  for (let i = 0; i < array.length; i++) {
    if (array[i] === value) {
      return i;
    }
  }

  return -1;
}

// Worse: https://jsben.ch/106Ql
// Normal: https://jsben.ch/y9B4G
// Like 70% slower for worst case
// Normal stuff not so bad but slower
const binarySearchRecursive = function(array, value, start = 0, end = array.length - 1) {
  const midIndex = Math.floor((start + end) / 2);
  const midValue = array[midIndex];

  if (midValue === value) {
    return midIndex;
  }

  if (start >= end) {
    return -1;
  } else if (midValue > value) {
    return binarySearch(array, value, 0, midIndex - 1);
  } else if (midValue < value) {
    return binarySearch(array, value, midIndex + 1, end);
  }

  return -1;
}

const binarySearch = function(array, value) {
  const getIntegerAverage = (start, end) => (start + end) >>> 1;

  const addOne = x => -~x;
  const minusOne = x => ~-x;

  // (a + b) >>> 1 === Math.floor((a + b) / 2)
  for (let start = 0, 
    end = minusOne(array.length), 
    midIndex = getIntegerAverage(start, end); 
    start <= end; 
    midIndex = getIntegerAverage(start, end)) {
    const midValue = array[midIndex];

    if (midValue === value) {
      return midIndex;
    } else if (array[midIndex] > value) {
      end = minusOne(midIndex); // n - 1
    } else {
      start = addOne(midIndex); // n + 1
    }
  }

  return -1;
}

module.exports = { linearSearch, binarySearch: binarySearchRecursive };
