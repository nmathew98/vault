'use strict'

function swap(arr, idx1, idx2) {
  const idx1Value = arr[idx1];
  const idx2Value = arr[idx2];

  arr[idx1] = idx2Value;
  arr[idx2] = idx1Value;
}

function bubbleSort(arr) {
  const sorted = [...arr];

  // Small items bubble up
  // Left part is sorted
  const shouldBubble = (arr, to, from) => arr[to] > arr[from];

  for (let i = 0; i < sorted.length - 1; i++) {
    for (let j = 0; j < sorted.length - 1 - i; j++) {
      if (shouldBubble(sorted, j, j + 1)) {
        swap(sorted, j, j + 1);
      }
    }
  }

  return sorted;
}

function selectionSort(arr) {
  const sorted = [...arr];

  const findMinIdx = (sorted, start) => {
    for (let j = start + 1, minIdx = start; j < sorted.length; j++) {
      if (sorted[j] < sorted[minIdx]) {
        minIdx = j;
      }

      if (j === sorted.length - 1 && minIdx !== start) {
        return minIdx;
      }
    }

    return -1;
  };

  for (let i = 0; i < sorted.length - 1; i++) {
    const max = i;
    const min = findMinIdx(sorted, max);

    if (~min) {
      swap(sorted, max, min);
    }
  }

  return sorted;
}

function insertionSort(arr) {  
  const sorted = [...arr];

  // Big items (relative to `deck[fromIdx]`) get shuffled to the right
  // Left part is sorted
  const shufflePolicy = (deck, fromIdx) => {
    const from = deck[fromIdx];

    return toIdx => deck[toIdx] > from;
  };

  for (let i = 1; i < sorted.length; i++) {
    const shouldShuffle = shufflePolicy(sorted, i);

    for (let j = i - 1; j >= 0; j--) {
      if (shouldShuffle(j)) {
        swap(sorted, j + 1, j);
      }
    }
  }

  return sorted;
}

function merge(arr1, arr2) {
  const merged = [];

  while (arr1.length > 0 && arr2.length > 0) {
    if (arr1[0] < arr2[0]) {
      merged.push(arr1.shift());
    } else {
      merged.push(arr2.shift());
    }    
  }

  return [...merged, ...arr1, ...arr2];
}

function partition(arr, left, right) {
  const pivotPolicy = (arr, pivotIdx) => {
    const pivotValue = arr[pivotIdx];

    return i => arr[i] < pivotValue;
  }
  const initialPivotPosition = left;
  // Pick any value as the pivot, in this case its `left`
  const isToLeftOfPartition = pivotPolicy(arr, initialPivotPosition);

  // Leave the pivot value untouched and move items first
  // Keep track of how many times the pivot has moved from its initial position
  // We keep track by moving the pivot each time we do a swap to partition the array
  // Once we've gone through all the items,
  // swap `initialPivotPosition` and `finalPivotPositon = swapStart - 1`
  // since we are starting from `left`
  for (let i = initialPivotPosition + 1, swapStart = initialPivotPosition + 1; i <= right; i++) {
    if (isToLeftOfPartition(i)) {
      swap(arr, i, swapStart);
      swapStart++;
    }

    if (i === right) {
      const finalPivotPosition = swapStart - 1;

      swap(arr, initialPivotPosition, finalPivotPosition);

      return finalPivotPosition;
    }
  }

  return -1;
}

function partitionRight(arr, left, right) {
  const pivotPolicy = (arr, pivotIdx) => {
    const pivotValue = arr[pivotIdx];

    return i => arr[i] > pivotValue;
  }
  const initialPivotPosition = right;
  const isToRightOfPartition = pivotPolicy(arr, initialPivotPosition);

  for (let i = initialPivotPosition - 1, swapStart = initialPivotPosition - 1; i >= left; i--) {
    if (isToRightOfPartition(i)) {
      swap(arr, i, swapStart);
      swapStart--;
    }

    if (i === left) {
      const finalPivotPosition = swapStart + 1;

      swap(arr, initialPivotPosition, finalPivotPosition);

      return finalPivotPosition;
    }
  }

  return -1;
}

// To generalize (anywhere along) same as before, but we cannot fix swap start like below
// and we need two for loops, one for: `left < pivotIdx`
// another one for: `i > pivotIdx && i <= right`
// and then just apply the policy
// It's behaving a little weird, can't just slide the pivot anywhere along and starting from right is failing
// for positive numbers
// => Can't be done because the conditions for iterating and comparing change depending on where
// the selected pivot index is
// => Just stick to left or right
// Where ever the selected pivot index is, everything before has to be less and everything after has to be greater
function partitionGeneralWorking(arr, left, right) {
  const pivotPolicy = (arr, pivotValue) => i => arr[i] > pivotValue;
  const pivotValue = arr[right];
  
  const isToRightOfPartition = pivotPolicy(arr, pivotValue);

  for (let i = right - 1, swapStart = right - 1; i >= left; i--) {
    if (isToRightOfPartition(i)) {
      swap(arr, i, swapStart);
      swapStart--;
    }

    if (i === left) {
      const finalPivotPosition = swapStart + 1;

      swap(arr, right, finalPivotPosition);

      return finalPivotPosition;
    }
  }

  return -1;
}

// Does not sort negative numbers
function partitionGeneralNotWorking(arr, left, right) {
  const pivotPolicy = (arr, pivotValue) => i => arr[i] > pivotValue;
  const pivotIdx = right - 1;
  const pivotValue = arr[pivotIdx];

  const isToRightOfPartition = pivotPolicy(arr, pivotValue);

  for (let i = right, swapStart = right; i >= left; i--) {

    if (isToRightOfPartition(i)) {
      swap(arr, i, swapStart);

      if (swapStart - 1 === pivotIdx) {
        swapStart -= 2;
      } else {
        swapStart--;
      }
    }

    if (i === left) {
      const finalPivotPosition = swapStart + 1;

      swap(arr, pivotIdx, finalPivotPosition);

      return finalPivotPosition;
    }
  }

  return -1;
}

function hoarePartition(arr, left, right) {
  const pivotIdx = (right + left) >>> 1;
  const pivot = arr[pivotIdx];

  let i = left - 1;
  let j = right + 1;

  while (true) {
    do {
      i++;
    } while (arr[i] < pivot);

    do {
      j--;
    } while (arr[j] > pivot);

    if (i >= j) {
      return j;
    }

    swap(arr, i, j);
  }
}

function mergeSort(arr) {
  if (arr.length === 1) {
    return arr;
  }

  const mid = arr.length >>> 1;
  const left = mergeSort(arr.slice(0, mid));
  const right = mergeSort(arr.slice(mid));

  return merge(left, right);
}

function quickSort(arr, left = 0, right = arr.length - 1) {
  const pivotIdx = partitionGeneralNotWorking(arr, left, right);

  if (~pivotIdx) {
    const leftEnd = pivotIdx - 1;
    if (arr.length > 0 && left < leftEnd) {
      quickSort(arr, left, leftEnd);    
    }

    const rightStart = pivotIdx + 1;
    if (arr.length > 0 && rightStart < right) {
      quickSort(arr, rightStart, right);    
    }    
  }

  return arr;
}

function quickSortHoare(arr, left = 0, right = arr.length - 1) {
  if (left >= 0 && right >= 0 && left < right) {
    const pivotIdx = hoarePartition(arr, left, right);

    quickSortHoare(arr, left, pivotIdx);
    quickSortHoare(arr, pivotIdx + 1, right);
  }

  return arr;
}

module.exports = {
  swap,
  bubbleSort,
  selectionSort,
  insertionSort,
  merge,
  partition,
  mergeSort,
  quickSort: quickSortHoare
};
