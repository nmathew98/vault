// Write a function named insertInBack that takes in the following:
//   value (a number)
//   list (a linked list)
// The function returns the linked list with the node inserted at the end.
// Example:
//    insertInBack(1 -> 2 -> 3 -> ., 4) produces 1 -> 2 -> 3 -> 4 -> .
function insertInBack(value, list) {
  if (!list) {
    return {
      value,
      next: null
    };
  }

  const updatedList = { ...list };
  for (let i = updatedList; i && (i.value || i.next); i = i.next) {
    if (!i.next) {
      i.next = {
        value,
        next: null
      }

      return updatedList;
    }
  }
}

// Write a function named removeNodeAtIndex that takes in the following:
//   list (a linked list)
//   index (a number)
// The function returns the linked list with the node at that index removed.
// Example:
//  removeNodeAtIndex(1 -> 2 -> 3 -> ., 1) produces 1 -> 3 -> .
function removeNodeAtIndex(list, index) {
  if (!list) return null;

  const arr = [];

  for (let i = list, j = 0; i && (i.value || i.next); i = i.next, j++) {
    if (j === index) {
      continue;
    }

    arr.push(i.value);
  }

  return arr.reverse().reduce((list, value, index) => ({
    value,
    next: index === 0 ? null : list
  }), Object.create(null));
}

// Write a function named reverse that takes in the following:
//   list (a linked list)
// The function returns a NEW linked list with the items in reverse order.
// Example:
//   1 -> 2 -> 3 -> . would produce 3 -> 2 -> 1 -> .
function reverse(list) {
  if (!list) return null;

  const arr = [];

  for (let i = list; i && (i.value || i.next); i = i.next) {
    arr.push(i.value);
  }

  return arr.reduce((list, value, index) => ({
    value,
    next: index === 0 ? null : list
  }), Object.create(null));
}

module.exports = {
  insertInBack,
  removeNodeAtIndex,
  reverse
};
