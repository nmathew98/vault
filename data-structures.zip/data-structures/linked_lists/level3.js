// Write a function named merge that takes in the following as arguments:
//   list1 - a linked list in sorted order
//   list2 - a linked list in sorted order
// The function returns a NEW linked list that is in sorted order.
// Example:
//    merge(1 -> 3 -> 5 -> ., 2 -> 4 -> 6 -> .) produces
//       1 -> 2 -> 3 -> 4 -> 5 -> 6 -> .
function merge(list1, list2) {
  if (!list1 || !list2) {
    return list1 || list2;
  }

  const arr = [];

  for (let i = list1; i && (i.value || i.next); i = i.next) {
    arr.push(i.value);
  }

  for (let j = list2; j && (j.value || j.next); j = j.next) {
    arr.push(j.value);
  }

  return arr.sort().reverse().reduce((list, value, index) => ({
    value,
    next: index === 0 ? null : list
  }), Object.create(null))
}

// Write a function named map, that takes in the following as arguments:
//   list - A linked list
//   fcn - a function that takes in the value of each node as an argument.
//         it returns a new value.
// The function returns a NEW linked list, where each node's value is the same as the function applied on the original linked list.
// Example:
//    map(1 -> 2 -> 3 -> ., (num) => num * 2) produces 2 -> 4 -> 6 -> .
function map(list, fcn) {
  if (!list) {
    return null;
  }

  const mappedList = { ...list };
  for (let i = mappedList; i && (i.value || i.next); i = i.next) {
    i.value = fcn(i.value);
  }

  return mappedList;
}

// Write a function named filter, that takes in the following as arguments:
//   list - A linked list
//   fcn - a function that takes in the value of each node as an argument and
//         returns a boolean.
// The function returns a NEW linked list, where each node's value is the same
// as the function applied on the original linked list.
// Example:
//    filter(1 -> 2 -> 3 -> 4 -> ., (num) => num % 2 === 0) produces
//        2 -> 4 -> 6 -> .
function filter(list, fcn) {
  if (!list) {
    return null;
  }

  const arr = [];
  for (let i = list; i && (i.value || i.next); i = i.next) {
    arr.push(i.value);
  }

  return arr.filter(fcn).reverse().reduce((list, value, index) => ({
    value,
    next: index === 0 ? null : list
  }), Object.create(null));
}

module.exports = {
  merge,
  map,
  filter
}
