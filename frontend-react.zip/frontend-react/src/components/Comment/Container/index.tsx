export const CommentContainer = ({ children }) => (
	<div className="col-xs-12 col-md-8 offset-md-2">{children}</div>
);
