export const Icon = ({ name }) => <i className={name} />;
