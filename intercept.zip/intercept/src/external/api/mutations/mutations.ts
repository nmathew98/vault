import { ThunkObjMap, GraphQLFieldConfig, GraphQLString } from "graphql";
import type { ServerRequest } from "../../../entities/shared/types/request";
import type { ServerResponse } from "../../../entities/shared/types/response";

export default function useMutations(
	request: ServerRequest,
	response: ServerResponse,
): GraphQLField {
	const mutations: GraphQLField = {
		world: {
			type: GraphQLString,
			args: {
				x: {
					type: GraphQLString,
				},
			},
			resolve: (_, { x }) => x,
		},
	};

	return mutations;
}

type GraphQLField = ThunkObjMap<GraphQLFieldConfig<any, any, any>>;
