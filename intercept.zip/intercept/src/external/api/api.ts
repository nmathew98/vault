import type { ServerRequest } from "../../entities/shared/types/request";
import type { ServerResponse } from "../../entities/shared/types/response";
import { graphql, GraphQLSchema } from "graphql";

let useSchema: () => GraphQLSchema;

async function api(request: ServerRequest, response: ServerResponse) {
	if (!useSchema) throw new Error("useSchema is undefined");

	const body = await request.body;

	if (typeof body !== "object" || !body.query)
		throw new Error("Invalid request");

	const result = await graphql({
		schema: useSchema(),
		source: body.query,
		variableValues: body.variables,
	});

	return response.json(result);
}

export default function useApiHandler(
	request: ServerRequest,
	response: ServerResponse,
	schema: () => GraphQLSchema,
) {
	useSchema = schema;

	return api(request, response);
}
