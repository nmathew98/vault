import { ThunkObjMap, GraphQLFieldConfig, GraphQLString } from "graphql";
import type { ServerRequest } from "../../../entities/shared/types/request";
import type { ServerResponse } from "../../../entities/shared/types/response";

export default function useQueries(
	request: ServerRequest,
	response: ServerResponse,
): GraphQLField {
	const queries: GraphQLField = {
		hello: {
			type: GraphQLString,
			resolve: () => "world",
		},
	};

	return queries;
}

type GraphQLField = ThunkObjMap<GraphQLFieldConfig<any, any, any>>;
