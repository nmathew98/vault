import {
	GraphQLFieldConfig,
	GraphQLObjectType,
	GraphQLSchema,
	ThunkObjMap,
} from "graphql";
import type { ServerRequest } from "../../entities/shared/types/request";
import type { ServerResponse } from "../../entities/shared/types/response";
import useQueries from "./queries/queries";
import useMutations from "./mutations/mutations";

export default function useSchema(
	request: ServerRequest,
	response: ServerResponse,
) {
	const schema = new GraphQLSchema({
		query: createQuery(request, response, useQueries),
		mutation: createMutation(request, response, useMutations),
		types: [],
	});

	return schema;
}

type GraphQLField = ThunkObjMap<GraphQLFieldConfig<any, any, any>>;

function createQuery(
	request: ServerRequest,
	response: ServerResponse,
	fields: (request: ServerRequest, response: ServerResponse) => GraphQLField,
) {
	return new GraphQLObjectType({
		name: "RootQueryType",
		fields: fields(request, response),
	});
}

function createMutation(
	request: ServerRequest,
	response: ServerResponse,
	fields: (request: ServerRequest, response: ServerResponse) => GraphQLField,
) {
	return new GraphQLObjectType({
		name: "RootMutationType",
		fields: fields(request, response),
	});
}
