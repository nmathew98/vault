import {
	normalizeURL,
	parseURL,
	parseQuery,
	ParsedURL as UFOParsedURL,
	QueryObject as UFOParsedQuery,
} from "ufo";
import type { URLParser, ParsedURL } from "../../entities/shared/packages/url";

export function makeURLParser(): URLParser {
	return Object.freeze({
		match(path: string, url: string) {
			const parsedURL: Partial<ParsedURL> = this.parse(url);

			const normalizedPath: string = path[0] === "/" ? path : `/${path}`;

			return normalizedPath === parsedURL.pathname;
		},
		parse: (url: string): Partial<ParsedURL> => {
			const parsedURL: UFOParsedURL = parseURL(normalizeURL(url));
			// The one in UFO doesn't return anything?
			const [host, port] = (
				parsedURL.host?.match(/([^/]*):(\d+)?/) || []
			).splice(1);
			const query: UFOParsedQuery = parseQuery(parsedURL.search);

			return Object.freeze({
				hash: parsedURL.hash,
				hostname: host,
				pathname: parsedURL.pathname,
				port: port,
				protocol: parsedURL.protocol?.replace(":", "") ?? "",
				query: query,
			});
		},
	});
}
