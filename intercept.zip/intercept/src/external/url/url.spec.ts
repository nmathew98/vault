import type { URLParser, ParsedURL } from "../../entities/shared/packages/url";
import { makeURLParser } from "./url";

const ufo: URLParser = makeURLParser();

describe("URL", () => {
	describe("match", () => {
		it("matches a path that starts without a slash", () => {
			expect(ufo.match("test", "http://localhost/test")).toStrictEqual(true);
		});

		it("matches a path that starts with a slash", () => {
			expect(ufo.match("/test", "http://localhost/test")).toStrictEqual(true);
		});

		it("matches an address that has a port specified", () => {
			expect(ufo.match("/test", "http://localhost:4000/test")).toStrictEqual(
				true,
			);
		});

		it("matches a path that has a query string", () => {
			expect(
				ufo.match("/test", "http://localhost/test?hello=world"),
			).toStrictEqual(true);
		});

		it("does not a path that is not addressed by the url", () => {
			expect(ufo.match("/test", "http://localhost/abc")).toStrictEqual(false);
		});
	});

	describe("parse", () => {
		it("returns an object", () => {
			const parsedURL: Partial<ParsedURL> = ufo.parse("http://localhost/test");

			expect(typeof parsedURL).toStrictEqual("object");
		});

		it("extracts the hash", () => {
			const parsedURLWithoutSlash: Partial<ParsedURL> = ufo.parse(
				"http://localhost#test",
			);
			const parsedURLWithSlash: Partial<ParsedURL> = ufo.parse(
				"http://localhost/#test",
			);

			expect(parsedURLWithoutSlash.hash).toStrictEqual("");
			expect(parsedURLWithSlash.hash).toStrictEqual("#test");
		});

		it("extracts the port", () => {
			const parsedURL: Partial<ParsedURL> = ufo.parse("http://localhost:4000/");

			expect(parsedURL.port).toStrictEqual("4000");
		});

		it("extracts the query", () => {
			const parsedURL: Partial<ParsedURL> = ufo.parse(
				"http://localhost:4000/?hello=world",
			);

			expect(parsedURL.query).toStrictEqual({ hello: "world" });
		});

		it("extracts the protocol", () => {
			const parsedURL: Partial<ParsedURL> = ufo.parse(
				"https://localhost:4000/?hello=world",
			);
			const parsedURLWithoutProtocol: Partial<ParsedURL> = ufo.parse(
				"localhost:4000/?hello=world",
			);

			expect(parsedURL.protocol).toStrictEqual("https");
			expect(parsedURLWithoutProtocol.protocol).toStrictEqual("");
		});
	});
});
