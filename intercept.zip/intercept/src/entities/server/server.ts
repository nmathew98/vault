import type { App } from "../app/app";
import type { URLParser, ParsedURL } from "../shared/packages/url";

export interface Server {
	/**
	 * Creates a proxy server to intercept fetch requests
	 *
	 * @param {App} app the app
	 * @returns {Server} Server object for chaining
	 */
	createServer: (app: App) => Server;
	/**
	 * Listens for outgoing fetch requests to `host`
	 *
	 * If a port is specified then all requests to that specific port will be intercepted
	 *
	 * @param {string} host the hostname to intercept
	 * @param {number} port port to listen on (optionally)
	 * @returns {void}
	 */
	listen: (host: string, port?: number) => void;
}

interface ServerInternals {
	_app: App | undefined;
}

export default function buildMakeServer({
	URLParser,
}: {
	URLParser: URLParser;
}) {
	return function makeServer() {
		const internals: ServerInternals = { _app: undefined };

		return Object.freeze({
			createServer: (app: App) => {
				internals._app = app;

				return app;
			},
			listen: (host: string, port?: number) => {
				if (!("serviceWorker" in navigator)) return;

				if (internals._app === undefined)
					throw new Error("Create a server before listening!");

				(self as unknown as ServiceWorkerGlobalScope).addEventListener(
					"fetch",
					async (event: FetchEvent) => {
						const parsedUrl: Partial<ParsedURL> = URLParser.parse(
							event.request.url,
						);

						if (
							("port" in parsedUrl &&
								parseInt(parsedUrl.port as string) !== port) ||
							("hostname" in parsedUrl && parsedUrl.hostname !== host)
						)
							return;

						event.respondWith(
							(await internals._app?.handle(event.request)) as Response,
						);
					},
				);
			},
		});
	};
}
