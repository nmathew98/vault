import type { AcceptParser } from "../shared/packages/accept-parser";
import type { RangeParser } from "../shared/packages/range-parser";
import type { Deprecate } from "../shared/packages/deprecate";
import type { ParsedURL, URLParser } from "../shared/packages/url";
import type { ServerRequest } from "../shared/types/request";
import Utils from "../shared/utils";

/**
 * The packages required to build a makeServerRequest function
 *
 * See src/entities/shared/types for the interfaces the packages must satisfy
 */
export interface ServerRequestPackages {
	AcceptParser: AcceptParser;
	Deprecate: Deprecate;
	RangeParser: RangeParser;
	URLParser: URLParser;
}

/**
 * Builder function to create a ServerRequest maker.
 * ServerRequest makers take in a Fetch Request object
 * and spit out a ServerRequest object that has the same properties
 * as an Express Request object
 *
 * @param {ServerRequestPackages} packages the packages required
 * @returns a Express Request object
 */
export function buildMakeServerRequest({
	AcceptParser,
	Deprecate,
	RangeParser,
	URLParser,
}: ServerRequestPackages) {
	return function makeServerRequest(request: Request): unknown & ServerRequest {
		const parsedURL: Partial<ParsedURL> = URLParser.parse(request?.url ?? "");

		const serverRequestMethods: ServerRequest = {
			get: (name: string): string | void => serverRequestMethods.header(name),
			header: (name: string): string | void => {
				if (Utils.isVoid(name))
					throw new SyntaxError("name argument is required to req.get");
				if (typeof name !== "string")
					throw new TypeError("name must be a string to req.get");

				const lowerCasedName: string = name.toLowerCase();
				if ("headers" in request)
					if ("get" in request.headers)
						switch (lowerCasedName) {
							case "referer":
							case "referrer":
								return request?.referrer;
							default:
								return request?.headers?.get(name) ?? undefined;
						}

				return;
			},
			accepts: (...types: string[]): string | void => {
				if (!("headers" in request)) return;

				return AcceptParser.type(request?.headers?.get("Accept") ?? "", types);
			},
			acceptsEncoding: (...encodings: string[]): string | void => {
				Deprecate.deprecate(
					"req.acceptsEncoding: Use acceptsEncodings instead",
				);

				return serverRequestMethods.acceptsEncodings(...encodings);
			},
			acceptsEncodings: (...encodings: string[]): string | void => {
				if (!("headers" in request)) return;

				return AcceptParser.encoding(
					request.headers.get("Accept-Encoding") ?? "",
					encodings,
				);
			},
			acceptsCharset: (...charsets: string[]): string | void => {
				Deprecate.deprecate("req.acceptsCharset: Use acceptsCharsets instead");

				return serverRequestMethods.acceptsCharsets(...charsets);
			},
			acceptsCharsets: (...charsets: string[]): string | void => {
				if (!("headers" in request)) return;

				return AcceptParser.charset(
					request?.headers?.get("Accept-Charset") ?? "",
					charsets,
				);
			},
			acceptsLanguage: (...languages: string[]): string | void => {
				Deprecate.deprecate(
					"req.acceptsLanguage: Use acceptsLanguages instead",
				);

				return serverRequestMethods.acceptsLanguages(...languages);
			},
			acceptsLanguages: (...languages: string[]): string | void => {
				if (!("headers" in request)) return;

				return AcceptParser.language(
					request?.headers?.get("Accept-Language") ?? "",
					languages,
				);
			},
			range: (
				size: number,
				options?: { combine: boolean },
			): { start: number; end: number; index?: number }[] | number | void => {
				if (!("headers" in request)) return;

				const range: string | null = request?.headers?.get("Range");
				if (Utils.isVoid(range)) return;

				return RangeParser.parse(size, range as string, options);
			},
			param: (name: string, defaultValue?: string): string | void => {
				const args: string =
					defaultValue === undefined ? "name" : "name, default";
				Deprecate.deprecate(
					`req.param(${args}): Use req.params, req.body or req.query instead`,
				);

				if ("query" in parsedURL)
					if (name in (parsedURL.query as Record<string, any>))
						return (parsedURL.query as Record<string, any>)[name];

				return defaultValue;
			},
			is: (...types: string[]): boolean => {
				const type: string | void = serverRequestMethods.accepts(...types);

				return !Utils.isVoid(type) ? true : false;
			},
		};
		const serverRequest: Record<string, any> = { ...serverRequestMethods };

		const otherProperties: Record<string, any> = Object.create(null);

		const proxy: unknown & ServerRequest = new Proxy(Object.create(null), {
			get: (_, property: string): any => {
				{
					Utils.defineGetter(
						serverRequest,
						"headers",
						(): Record<string, string> => {
							const headers: Record<string, string> = Object.create(null);

							if ("headers" in otherProperties) return otherProperties.headers;

							if (!("headers" in request)) return headers;

							request?.headers?.forEach((value: string, header: string) => {
								headers[header] = value;
							});

							otherProperties.headers = headers;

							return headers;
						},
					);
					Utils.defineGetter(
						serverRequest,
						"protocol",
						(): string | void => parsedURL.protocol,
					);
					Utils.defineGetter(
						serverRequest,
						"secure",
						(): boolean => parsedURL.protocol === "https",
					);
					Utils.defineGetter(
						serverRequest,
						"trailers",
						(): Record<string, string> => Object.create(null),
					);
					Utils.defineGetter(serverRequest, "statusCode", (): number => -1);
					Utils.defineGetter(serverRequest, "statusMessage", (): string => "");
					Utils.defineGetter(serverRequest, "httpVersion", (): string => "");
					Utils.defineGetter(serverRequest, "ip", (): string => "");
					Utils.defineGetter(serverRequest, "ips", (): string[] => []);
					Utils.defineGetter(serverRequest, "subdomains", (): string[] => []);
					Utils.defineGetter(
						serverRequest,
						"path",
						(): string | void => parsedURL.pathname,
					);
					Utils.defineGetter(
						serverRequest,
						"hostname",
						(): string | void => parsedURL.hostname,
					);
					Utils.defineGetter(serverRequest, "host", (): string | void => {
						Deprecate.deprecate("req.host: Use req.hostname instead");

						return parsedURL.hostname;
					});
					Utils.defineGetter(serverRequest, "fresh", (): boolean => true);
					Utils.defineGetter(serverRequest, "stale", (): boolean => false);
					Utils.defineGetter(serverRequest, "xhr", (): boolean => {
						const requestedWith: string =
							request?.headers?.get("X-Requested-With") ?? "";

						return requestedWith.toLowerCase() === "xmlhttprequest";
					});
					Utils.defineGetter(serverRequest, "url", (): string => request?.url);
					Utils.defineGetter(
						serverRequest,
						"method",
						(): string => request?.method,
					);
				}

				return serverRequest[property] ?? otherProperties[property];
			},
			set: (_, property: string, value: any): boolean => {
				if (!(property in serverRequest))
					return (otherProperties[property] = value), true;

				return false;
			},
		});

		return Object.freeze(proxy);
	};
}

/**
 * Use a ServerRequest object in place of a Fetch Request object
 *
 * @param {ServerRequest} serverRequest the ServerRequest object
 * @returns a Fetch Request object
 */
export function useServerRequest(
	serverRequest: unknown & ServerRequest,
): Request {
	if (Utils.isVoid(serverRequest?.url))
		throw new Error("Not a valid ServerRequest");

	const request: Request = new Request(serverRequest?.url, {
		headers: new Headers(serverRequest?.headers),
		body: serverRequest?.body,
		cache: "default",
		referrer: serverRequest?.header("Referrer") ?? "",
		referrerPolicy:
			(serverRequest?.header("Referrer-Policy") as ReferrerPolicy) ?? "",
		method: serverRequest?.method,
	});

	const fetchRequestMethods: Record<string, any> = {
		arrayBuffer: async (): Promise<ArrayBuffer | void> => {
			if (Utils.isVoid(serverRequest?.body)) return;

			return request.arrayBuffer();
		},
		blob: async (): Promise<Blob | void> => {
			if (Utils.isVoid(serverRequest?.body)) return;

			return request?.blob();
		},
		clone: (): Request => {
			return { ...request };
		},
		formData: async (): Promise<FormData | void> => {
			if (Utils.isVoid(serverRequest?.body)) return;

			return request?.formData();
		},
		json: async (): Promise<Record<string, any> | void> => {
			if (Utils.isVoid(serverRequest?.body)) return;

			return request?.json();
		},
		text: async (): Promise<string | void> => {
			if (Utils.isVoid(serverRequest?.body)) return;

			return request?.text();
		},
	};
	const fetchRequest: Record<string, any> = { ...fetchRequestMethods };

	const otherProperties: Record<string, any> = Object.create(null);

	const proxy: Request = new Proxy(Object.create(null), {
		get: (_, property: string): any => {
			return (
				fetchRequest[property] ??
				otherProperties[property] ??
				request[property as keyof Request]
			);
		},
		set: (_, property: string, value: any): boolean => {
			if (!(property in fetchRequest))
				return (otherProperties[property] = value), true;

			return false;
		},
	});

	return Object.freeze(proxy);
}
