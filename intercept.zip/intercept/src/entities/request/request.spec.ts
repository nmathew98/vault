import type { URLParser } from "../shared/packages/url";
import type { AcceptParser } from "../shared/packages/accept-parser";
import type { Deprecate } from "../shared/packages/deprecate";
import type { RangeParser } from "../shared/packages/range-parser";
import type { ServerRequest } from "../shared/types/request";
import { buildMakeServerRequest, useServerRequest } from "./request";

describe("ServerRequest", () => {
	describe("makeServerRequest", () => {
		let AcceptParser: AcceptParser;
		let Deprecate: Deprecate;
		let RangeParser: RangeParser;
		let URLParser: URLParser;
		let makeServerRequest: (...args: any[]) => ServerRequest;

		beforeAll(() => {
			global.Request = jest
				.fn()
				.mockImplementation((url: string, options?: RequestInit) => {
					const headers: Headers = new Headers();

					return {
						headers,
						url,
						referrer: "about:client",
						method: options?.method,
					};
				});
			global.Headers = jest.fn().mockImplementation(() => {
				const headers: Record<string, any> = {};

				return {
					get: (header: string) => {
						return headers[header.toLowerCase()];
					},
					set: (header: string, value: string) => {
						headers[header.toLowerCase()] = value;
					},
					forEach: (fn: (value: string, key: string) => void) => {
						for (const header in headers) {
							fn(headers[header], header);
						}
					},
				};
			});
		});

		beforeEach(() => {
			AcceptParser = {
				type: jest
					.fn()
					.mockImplementation((types: string, preferences: string[]) =>
						preferences.includes(types) ? true : undefined,
					),
				charset: jest.fn(),
				encoding: jest.fn(),
				language: jest.fn(),
			};
			Deprecate = {
				deprecate: jest.fn(),
			};
			RangeParser = {
				parse: jest.fn(),
			};
			URLParser = {
				match: jest.fn(),
				parse: jest.fn().mockImplementation((url: string) => {
					return {
						hash: url,
						hostname: url,
						pathname: url,
						port: "3000",
						protocol: "https",
						query: {
							x: "y",
						},
					};
				}),
			};

			makeServerRequest = buildMakeServerRequest({
				AcceptParser,
				Deprecate,
				RangeParser,
				URLParser,
			});
		});

		describe("intercepts property access for keys in ServerRequest", () => {
			describe("methods", () => {
				it("throws an error if header arguments are invalid", () => {
					const request: Request = new Request("http://www.test.com");

					const serverRequest: ServerRequest = makeServerRequest(request);

					try {
						serverRequest.header(undefined as unknown as string);
					} catch (error: any) {
						expect(error.message).toStrictEqual(
							"name argument is required to req.get",
						);
					}

					try {
						serverRequest.header(2 as unknown as string);
					} catch (error: any) {
						expect(error.message).toStrictEqual(
							"name must be a string to req.get",
						);
					}
				});

				it("gets headers", () => {
					const request: Request = new Request("http://www.test.com");
					request.headers.set("Content-Type", "text/plain");

					const serverRequest: ServerRequest = makeServerRequest(request);

					expect(serverRequest.get("content-type")).toStrictEqual("text/plain");
					expect(serverRequest.header("content-type")).toStrictEqual(
						"text/plain",
					);
					expect(serverRequest.get("x")).toStrictEqual(undefined);
					expect(serverRequest.header("x")).toStrictEqual(undefined);

					const noHeaderServerRequest = makeServerRequest(Object.create(null));

					expect(noHeaderServerRequest.get("content-type")).toBeFalsy();
				});

				it("gets the referrer from referrer on request if it is available", () => {
					const request: Request = new Request("http://www.test.com");

					const serverRequest: ServerRequest = makeServerRequest(request);

					expect(serverRequest.get("referer")).toStrictEqual("about:client");
					expect(serverRequest.header("referrer")).toStrictEqual(
						"about:client",
					);
				});

				it("checks if the given types are acceptable", () => {
					const request: Request = new Request("http://www.test.com");
					request.headers.set("Accept", "");

					const serverRequest: ServerRequest = makeServerRequest(request);

					serverRequest.accepts("");

					expect(AcceptParser.type).toBeCalledTimes(1);

					const noHeaderServerRequest = makeServerRequest(Object.create(null));
					expect(noHeaderServerRequest.accepts("")).toBeFalsy();
				});

				it("checks if the given types are acceptable if 'Accept' is undefined", () => {
					const request: Request = new Request("http://www.test.com");

					const serverRequest: ServerRequest = makeServerRequest(request);

					serverRequest.accepts("");

					expect(AcceptParser.type).toBeCalledTimes(1);

					const noHeaderServerRequest = makeServerRequest(Object.create(null));
					expect(noHeaderServerRequest.accepts("")).toBeFalsy();
				});

				it("checks if the given encodings are acceptable", () => {
					const request: Request = new Request("http://www.test.com");
					request.headers.set("Accept-Encoding", "");

					const serverRequest: ServerRequest = makeServerRequest(request);

					serverRequest.acceptsEncoding("");
					serverRequest.acceptsEncodings("");

					expect(AcceptParser.encoding).toBeCalledTimes(2);
					expect(Deprecate.deprecate).toBeCalledTimes(1);

					const noHeaderServerRequest = makeServerRequest(Object.create(null));
					expect(noHeaderServerRequest.acceptsEncoding("")).toBeFalsy();
					expect(noHeaderServerRequest.acceptsEncodings("")).toBeFalsy();
				});

				it("checks if the given encodings are acceptable if 'Accept-Encoding' is undefined", () => {
					const request: Request = new Request("http://www.test.com");

					const serverRequest: ServerRequest = makeServerRequest(request);

					serverRequest.acceptsEncoding("");
					serverRequest.acceptsEncodings("");

					expect(AcceptParser.encoding).toBeCalledTimes(2);
					expect(Deprecate.deprecate).toBeCalledTimes(1);

					const noHeaderServerRequest = makeServerRequest(Object.create(null));
					expect(noHeaderServerRequest.acceptsEncoding("")).toBeFalsy();
					expect(noHeaderServerRequest.acceptsEncodings("")).toBeFalsy();
				});

				it("checks if the given charsets are acceptable", () => {
					const request: Request = new Request("http://www.test.com");
					request.headers.set("Accept-Charset", "");

					const serverRequest: ServerRequest = makeServerRequest(request);

					serverRequest.acceptsCharset("");
					serverRequest.acceptsCharsets("");

					expect(AcceptParser.charset).toBeCalledTimes(2);
					expect(Deprecate.deprecate).toBeCalledTimes(1);

					const noHeaderServerRequest = makeServerRequest(Object.create(null));
					expect(noHeaderServerRequest.acceptsCharset("")).toBeFalsy();
					expect(noHeaderServerRequest.acceptsCharsets("")).toBeFalsy();
				});

				it("checks if the given charsets are acceptable if 'Accept-Charset' is undefined", () => {
					const request: Request = new Request("http://www.test.com");

					const serverRequest: ServerRequest = makeServerRequest(request);

					serverRequest.acceptsCharset("");
					serverRequest.acceptsCharsets("");

					expect(AcceptParser.charset).toBeCalledTimes(2);
					expect(Deprecate.deprecate).toBeCalledTimes(1);

					const noHeaderServerRequest = makeServerRequest(Object.create(null));
					expect(noHeaderServerRequest.acceptsCharset("")).toBeFalsy();
					expect(noHeaderServerRequest.acceptsCharsets("")).toBeFalsy();
				});

				it("checks if the given languages are acceptable", () => {
					const request: Request = new Request("http://www.test.com");
					request.headers.set("Accept-Language", "");

					const serverRequest: ServerRequest = makeServerRequest(request);

					serverRequest.acceptsLanguage("");
					serverRequest.acceptsLanguages("");

					expect(AcceptParser.language).toBeCalledTimes(2);
					expect(Deprecate.deprecate).toBeCalledTimes(1);

					const noHeaderServerRequest = makeServerRequest(Object.create(null));
					expect(noHeaderServerRequest.acceptsLanguage("")).toBeFalsy();
					expect(noHeaderServerRequest.acceptsLanguages("")).toBeFalsy();
				});

				it("checks if the given languages are acceptable if 'Accept-Language' is undefined", () => {
					const request: Request = new Request("http://www.test.com");

					const serverRequest: ServerRequest = makeServerRequest(request);

					serverRequest.acceptsLanguage("");
					serverRequest.acceptsLanguages("");

					expect(AcceptParser.language).toBeCalledTimes(2);
					expect(Deprecate.deprecate).toBeCalledTimes(1);

					const noHeaderServerRequest = makeServerRequest(Object.create(null));
					expect(noHeaderServerRequest.acceptsLanguage("")).toBeFalsy();
					expect(noHeaderServerRequest.acceptsLanguages("")).toBeFalsy();
				});

				it("parses the range header", () => {
					const request: Request = new Request("http://www.test.com");
					request.headers.set("Range", "");

					const serverRequest: ServerRequest = makeServerRequest(request);

					serverRequest.range(100);

					expect(RangeParser.parse).toBeCalledTimes(1);

					const noHeaderServerRequest = makeServerRequest(Object.create(null));
					expect(noHeaderServerRequest.range(100)).toBeFalsy();
				});

				it("returns if there is no range", () => {
					const request: Request = new Request("http://www.test.com");

					const serverRequest: ServerRequest = makeServerRequest(request);
					serverRequest.range(100);

					expect(RangeParser.parse).toBeCalledTimes(0);
				});

				it("returns the param is there is a query", () => {
					const request: Request = new Request("http://www.test.com");

					const serverRequest: ServerRequest = makeServerRequest(request);

					expect(serverRequest.param("x")).toStrictEqual("y");
					expect(Deprecate.deprecate).toBeCalledTimes(1);
					expect(Deprecate.deprecate).toBeCalledWith(
						"req.param(name): Use req.params, req.body or req.query instead",
					);
				});

				it("returns the default value for param if there is none", () => {
					const request: Request = new Request("http://www.test.com");

					const serverRequest: ServerRequest = makeServerRequest(request);

					expect(serverRequest.param("z", "a")).toStrictEqual("a");
					expect(Deprecate.deprecate).toBeCalledTimes(1);
					expect(Deprecate.deprecate).toBeCalledWith(
						"req.param(name, default): Use req.params, req.body or req.query instead",
					);
				});

				it("returns true if some content type is allowed", () => {
					const request: Request = new Request("http://www.test.com");
					request.headers.set("Accept", "html");

					const serverRequest: ServerRequest = makeServerRequest(request);

					expect(serverRequest.is("html")).toStrictEqual(true);
					expect(AcceptParser.type).toBeCalledTimes(1);

					const noHeaderServerRequest = makeServerRequest(Object.create(null));

					expect(noHeaderServerRequest.is("")).toStrictEqual(false);
				});

				it("returns false if some content type is not allowed", () => {
					const request: Request = new Request("http://www.test.com");
					request.headers.set("Accept", "html");

					const serverRequest: ServerRequest = makeServerRequest(request);

					expect(serverRequest.is("text")).toStrictEqual(false);
					expect(AcceptParser.type).toBeCalledTimes(1);
				});
			});

			describe("getters", () => {
				it("has a getter for headers", () => {
					const request: Request = new Request("http://www.test.com");
					request.headers.set("Content-Type", "text/plain");

					const serverRequest: ServerRequest = makeServerRequest(request);

					const headers: Record<string, string> =
						serverRequest.headers as Record<string, string>;

					expect(headers["content-type"]).toStrictEqual("text/plain");
					expect(serverRequest.headers).not.toBeFalsy();

					const noHeaderServerRequest = makeServerRequest(Object.create(null));

					expect(
						Object.keys(
							noHeaderServerRequest.headers as Record<string, string>,
						),
					).toStrictEqual([]);
				});

				it("has a getter for protocol", () => {
					const request: Request = new Request("http://www.test.com");

					const serverRequest: ServerRequest = makeServerRequest(request);

					expect(serverRequest.protocol).toStrictEqual("https");
				});

				it("has a getter for secure", () => {
					const request: Request = new Request("http://www.test.com");

					const serverRequest: ServerRequest = makeServerRequest(request);

					expect(serverRequest.secure).toStrictEqual(true);
				});

				it("has a getter for ip which returns an empty string", () => {
					const request: Request = new Request("http://www.test.com");

					const serverRequest: ServerRequest = makeServerRequest(request);

					expect(serverRequest.ip).toStrictEqual("");
				});

				it("has a getter for ips which returns an empty string", () => {
					const request: Request = new Request("http://www.test.com");

					const serverRequest: ServerRequest = makeServerRequest(request);

					expect(serverRequest.ips).toStrictEqual([]);
				});

				it("has a getter for subdomains which returns an empty array", () => {
					const request: Request = new Request("http://www.test.com");

					const serverRequest: ServerRequest = makeServerRequest(request);

					expect(serverRequest.subdomains).toStrictEqual([]);
				});

				it("has a getter for path which returns the path requested if there is a url", () => {
					const request: Request = new Request("http://www.test.com");

					const serverRequest: ServerRequest = makeServerRequest(request);

					expect(serverRequest.path).toStrictEqual("http://www.test.com");
				});

				it("has a getter for hostname which returns the hostname if there is a url", () => {
					const request: Request = new Request("http://www.test.com");

					const serverRequest: ServerRequest = makeServerRequest(request);

					expect(serverRequest.hostname).toStrictEqual("http://www.test.com");
				});

				it("has a getter for host which returns the hostname if there is a url", () => {
					const request: Request = new Request("http://www.test.com");

					const serverRequest: ServerRequest = makeServerRequest(request);

					expect(serverRequest.host).toStrictEqual("http://www.test.com");
					expect(Deprecate.deprecate).toBeCalledTimes(1);
				});

				it("has a getter for fresh which returns true", () => {
					const request: Request = new Request("http://www.test.com");

					const serverRequest: ServerRequest = makeServerRequest(request);

					expect(serverRequest.fresh).toStrictEqual(true);
				});

				it("has a getter for stale which returns false", () => {
					const request: Request = new Request("http://www.test.com");

					const serverRequest: ServerRequest = makeServerRequest(request);

					expect(serverRequest.stale).toStrictEqual(false);
				});

				it("has a getter for xhr which returns true if X-Requested-With is xmlhttprequest", () => {
					const request: Request = new Request("http://www.test.com");
					request.headers.set("X-Requested-With", "xmlhttprequest");

					const serverRequest: ServerRequest = makeServerRequest(request);

					expect(serverRequest.xhr).toStrictEqual(true);
				});

				it("has a getter for xhr which returns false if X-Requested-With is not xmlhttprequest", () => {
					const request: Request = new Request("http://www.test.com");
					request.headers.set("X-Requested-With", "");

					const serverRequest: ServerRequest = makeServerRequest(request);

					expect(serverRequest.xhr).toStrictEqual(false);
				});

				it("has a getter for xhr which returns false if X-Requested-With is not set", () => {
					const request: Request = new Request("http://www.test.com");

					const serverRequest: ServerRequest = makeServerRequest(request);

					expect(serverRequest.xhr).toStrictEqual(false);
				});

				it("has a getter for the url of the request", () => {
					const request: Request = new Request("http://www.test.com");

					const serverRequest: ServerRequest = makeServerRequest(request);

					expect(serverRequest.url).toStrictEqual("http://www.test.com");
				});

				it("has a getter for trailers", () => {
					const request: Request = new Request("http://www.test.com");

					const serverRequest: ServerRequest = makeServerRequest(request);

					expect(serverRequest.trailers).toStrictEqual(Object.create(null));
				});

				it("has a getter for the status code", () => {
					const request: Request = new Request("http://www.test.com");

					const serverRequest: ServerRequest = makeServerRequest(request);

					expect(serverRequest.statusCode).toStrictEqual(-1);
				});

				it("has a getter for the status message", () => {
					const request: Request = new Request("http://www.test.com");

					const serverRequest: ServerRequest = makeServerRequest(request);

					expect(serverRequest.statusMessage).toStrictEqual("");
				});

				it("has a getter for the http version", () => {
					const request: Request = new Request("http://www.test.com");

					const serverRequest: ServerRequest = makeServerRequest(request);

					expect(serverRequest.httpVersion).toStrictEqual("");
				});

				it("has a getter for the HTTP method of the request", () => {
					const request: Request = new Request("http://www.test.com", {
						method: "POST",
					});

					const serverRequest: ServerRequest = makeServerRequest(request);

					expect(serverRequest.method).toStrictEqual("POST");
				});
			});
		});

		describe("intercepts property mutations for keys in ServerRequest", () => {
			it("setting a property leaves the Request unchanged", () => {
				const request: Request = new Request("http://www.test.com");

				const serverRequest: ServerRequest = makeServerRequest(request);

				(serverRequest as any).x = "y";

				expect((serverRequest as any).x).toStrictEqual("y");
				expect((request as any).x).toBeUndefined();
			});

			it("does not set a property that exists on ServerRequest", () => {
				const request: Request = new Request("http://www.test.com");

				const serverRequest: ServerRequest = makeServerRequest(request);

				try {
					serverRequest.accepts = () => {
						return;
					};
				} catch (error: any) {
					expect(error.message).not.toBeUndefined();
				}
			});
		});
	});

	describe("useServerRequest", () => {
		let AcceptParser: AcceptParser;
		let Deprecate: Deprecate;
		let RangeParser: RangeParser;
		let URLParser: URLParser;
		let makeServerRequest: (...args: any[]) => ServerRequest;

		beforeAll(() => {
			global.Request = jest
				.fn()
				.mockImplementation((url: string, options?: RequestInit) => {
					const headers: Headers = (options?.headers as any) ?? new Headers();

					return {
						headers,
						url,
						referrer: options?.referrer,
						referrerPolicy: options?.referrerPolicy ?? true,
						body: options?.body ?? true,
						bodyUsed: true,
						cache: options?.cache || true,
						credentials: options?.credentials ?? true,
						integrity: options?.integrity ?? true,
						destination: true,
						method: options?.method ?? true,
						mode: options?.method ?? true,
						redirect: options?.redirect ?? true,
						arrayBuffer: () => true,
						blob: () => true,
						formData: () => true,
						json: () => true,
						text: () => true,
					};
				});
			global.Headers = jest
				.fn()
				.mockImplementation((init?: Record<string, string>) => {
					const headers: Record<string, any> = init || Object.create(null);

					return {
						get: (header: string) => {
							return headers[header.toLowerCase()];
						},
						set: (header: string, value: string) => {
							headers[header.toLowerCase()] = value;
						},
						forEach: (fn: (value: string, key: string) => void) => {
							for (const header in headers) {
								fn(headers[header], header);
							}
						},
					};
				});
		});

		beforeEach(() => {
			AcceptParser = {
				type: jest
					.fn()
					.mockImplementation((types: string, preferences: string[]) =>
						preferences.includes(types) ? true : undefined,
					),
				charset: jest.fn(),
				encoding: jest.fn(),
				language: jest.fn(),
			};
			Deprecate = {
				deprecate: jest.fn(),
			};
			RangeParser = {
				parse: jest.fn(),
			};
			URLParser = {
				match: jest.fn(),
				parse: jest.fn().mockImplementation((url: string) => {
					return {
						hash: url,
						hostname: url,
						pathname: url,
						port: "3000",
						protocol: "https",
						query: {
							x: "y",
						},
					};
				}),
			};

			makeServerRequest = buildMakeServerRequest({
				AcceptParser,
				Deprecate,
				RangeParser,
				URLParser,
			});
		});

		it("throws an error if the ServerRequest does not have a url", () => {
			const serverRequest: ServerRequest = Object.create(null);

			try {
				useServerRequest(serverRequest);
			} catch (error: any) {
				expect(error.message).toStrictEqual("Not a valid ServerRequest");
			}
		});

		describe("intercepts property access for keys in FetchRequest", () => {
			describe("methods", () => {
				it("has an arrayBuffer method", async () => {
					const request: Request = new Request("http://www.test.com");

					const serverRequest: ServerRequest = makeServerRequest(request);
					const usedRequest: Request = useServerRequest(serverRequest);

					expect(await usedRequest.arrayBuffer()).toBeUndefined();

					serverRequest.body = "Hello world";

					expect(await usedRequest.arrayBuffer()).toStrictEqual(true);
				});

				it("has a blob method", async () => {
					const request: Request = new Request("http://www.test.com");

					const serverRequest: ServerRequest = makeServerRequest(request);
					const usedRequest: Request = useServerRequest(serverRequest);

					expect(await usedRequest.blob()).toBeUndefined();

					serverRequest.body = "Hello world";

					expect(await usedRequest.blob()).toStrictEqual(true);
				});

				it("has a clone method", async () => {
					const request: Request = new Request("http://www.test.com");

					const serverRequest: ServerRequest = makeServerRequest(request);
					serverRequest.body = "Hello world";

					const usedRequest: Request = useServerRequest(serverRequest);

					expect(usedRequest.clone()).not.toBeUndefined();
				});

				it("has a formData method", async () => {
					const request: Request = new Request("http://www.test.com");

					const serverRequest: ServerRequest = makeServerRequest(request);
					const usedRequest: Request = useServerRequest(serverRequest);

					expect(await usedRequest.formData()).toBeUndefined();

					serverRequest.body = "Hello world";

					expect(await usedRequest.formData()).toStrictEqual(true);
				});

				it("has a json method", async () => {
					const request: Request = new Request("http://www.test.com");

					const serverRequest: ServerRequest = makeServerRequest(request);
					const usedRequest: Request = useServerRequest(serverRequest);

					expect(await usedRequest.json()).toBeUndefined();

					serverRequest.body = "Hello world";

					expect(await usedRequest.json()).toStrictEqual(true);
				});

				it("has a text method", async () => {
					const request: Request = new Request("http://www.test.com");

					const serverRequest: ServerRequest = makeServerRequest(request);
					const usedRequest: Request = useServerRequest(serverRequest);

					expect(await usedRequest.text()).toBeUndefined();

					serverRequest.body = "Hello world";

					expect(await usedRequest.text()).toStrictEqual(true);
				});
			});

			describe("getters", () => {
				it("has a getter for the body", () => {
					const request: Request = new Request("http://www.test.com");

					const serverRequest: ServerRequest = makeServerRequest(request);
					const usedRequest: Request = useServerRequest(serverRequest);

					expect(usedRequest.body).toStrictEqual(true);
				});

				it("has a getter to indicate if the body has been used", () => {
					const request: Request = new Request("http://www.test.com");

					const serverRequest: ServerRequest = makeServerRequest(request);
					const usedRequest: Request = useServerRequest(serverRequest);

					expect(usedRequest.bodyUsed).toStrictEqual(true);
				});

				it("has a getter for the cache policy", () => {
					const request: Request = new Request("http://www.test.com");

					const serverRequest: ServerRequest = makeServerRequest(request);
					const usedRequest: Request = useServerRequest(serverRequest);

					expect(usedRequest.cache).toStrictEqual("default");
				});

				it("has a getter for the credentials", () => {
					const request: Request = new Request("http://www.test.com");

					const serverRequest: ServerRequest = makeServerRequest(request);
					const usedRequest: Request = useServerRequest(serverRequest);

					expect(usedRequest.credentials).toStrictEqual(true);
				});

				it("has a getter for the destination", () => {
					const request: Request = new Request("http://www.test.com");

					const serverRequest: ServerRequest = makeServerRequest(request);
					const usedRequest: Request = useServerRequest(serverRequest);

					expect(usedRequest.destination).toStrictEqual(true);
				});

				it("has a getter for the headers", () => {
					const request: Request = new Request("http://www.test.com");
					request.headers.set("Content-Type", "text/plain");

					const serverRequest: ServerRequest = makeServerRequest(request);
					const usedRequest: Request = useServerRequest(serverRequest);

					expect(usedRequest.headers.get("Content-Type")).toStrictEqual(
						"text/plain",
					);
				});

				it("has a getter for the integrity", () => {
					const request: Request = new Request("http://www.test.com");

					const serverRequest: ServerRequest = makeServerRequest(request);
					const usedRequest: Request = useServerRequest(serverRequest);

					expect(usedRequest.integrity).toStrictEqual(true);
				});

				it("has a getter for the request method", () => {
					const request: Request = new Request("http://www.test.com");

					const serverRequest: ServerRequest = makeServerRequest(request);
					const usedRequest: Request = useServerRequest(serverRequest);

					expect(usedRequest.method).toStrictEqual(true);
				});

				it("has a getter for the mode of the request", () => {
					const request: Request = new Request("http://www.test.com");

					const serverRequest: ServerRequest = makeServerRequest(request);
					const usedRequest: Request = useServerRequest(serverRequest);

					expect(usedRequest.mode).toStrictEqual(true);
				});

				it("has a getter for how redirects are handled", () => {
					const request: Request = new Request("http://www.test.com");

					const serverRequest: ServerRequest = makeServerRequest(request);
					const usedRequest: Request = useServerRequest(serverRequest);

					expect(usedRequest.redirect).toStrictEqual(true);
				});

				it("has a getter for the referrer of the request", () => {
					const request: Request = new Request("http://www.test.com");

					const serverRequest: ServerRequest = makeServerRequest(request);
					const usedRequest: Request = useServerRequest(serverRequest);

					expect(usedRequest.referrer).toStrictEqual("");
				});

				it("has a getter for the referrer policy of the request", () => {
					const request: Request = new Request("http://www.test.com");

					const serverRequest: ServerRequest = makeServerRequest(request);
					const usedRequest: Request = useServerRequest(serverRequest);

					expect(usedRequest.referrerPolicy).toStrictEqual("");
				});

				it("has a getter for the url of the request", () => {
					const request: Request = new Request("http://www.test.com");

					const serverRequest: ServerRequest = makeServerRequest(request);
					const usedRequest: Request = useServerRequest(serverRequest);

					expect(usedRequest.url).toStrictEqual("http://www.test.com");
				});
			});
		});

		describe("intercepts property mutations for keys in FetchRequest", () => {
			it("sets a property if the property does not exist on FetchRequest", () => {
				const request: Request = new Request("http://www.test.com");

				const serverRequest: ServerRequest = makeServerRequest(request);
				const usedRequest: Request = useServerRequest(serverRequest);

				(usedRequest as any).x = "y";

				expect((usedRequest as any).x).toStrictEqual("y");
			});

			it("does not set a property that exists on FetchRequest", () => {
				const request: Request = new Request("http://www.test.com");

				const serverRequest: ServerRequest = makeServerRequest(request);
				const usedRequest: Request = useServerRequest(serverRequest);

				try {
					usedRequest.json = async () => {
						return;
					};
				} catch (error: any) {
					expect(error.message).not.toBeUndefined();
				}
			});
		});
	});
});
