import type { URLParser, ParsedURL } from "../shared/packages/url";
import type { Deprecate } from "../shared/packages/deprecate";
import type {
	StringyDataParser,
	StringyData,
	BinaryData,
	BinaryEncoding,
} from "../shared/packages/data-parser";
import type { Statuses } from "../shared/packages/statuses";
import type { Charset } from "../shared/packages/charset";
import type { ServerResponse } from "../shared/types/response";
import Utils from "../shared/utils";
import { StatusCodes } from "../../entities/shared/status-codes";

/**
 * The packages required to build a makeServerResponse function
 *
 * See src/entities/shared/types for the interfaces the packages must satisfy
 */
export interface ServerResponsePackages {
	URLParser: URLParser;
	Deprecate: Deprecate;
	StringyDataParser: StringyDataParser;
	Statuses: Statuses;
	Charset: Charset;
}

/**
 * Builder function to create a ServerResponse maker.
 * ServerResponse makers take in a Fetch Response object
 * and spit out a ServerResponse object that has the same properties
 * as an Express Response object
 *
 * @param {ServerResponsePackages} packages the packages required
 * @returns a Express Response object
 */
export function buildMakeServerResponse({
	URLParser,
	Deprecate,
	StringyDataParser,
	Statuses,
	Charset,
}: ServerResponsePackages) {
	return function makeServerResponse(
		response: Response,
	): unknown & ServerResponse {
		const parsedURL: Partial<ParsedURL> = URLParser.parse(response.url ?? "");

		const serverResponseMethods: ServerResponse = {
			status: (code: number): ServerResponse => {
				otherProperties.statusCode = code;

				return proxy;
			},
			links: (links: Record<string, string>): ServerResponse => {
				const linkHeader: string =
					serverResponseMethods.get("Link")?.concat(",") || "";

				const newLinks: string = Object.keys(links)
					.map((rel: string) => `<${links[rel]}>; rel="${rel}"`)
					.join(", ");

				return serverResponseMethods.set("Link", `${linkHeader} ${newLinks}`);
			},
			send: (content: StringyData | BinaryData): ServerResponse => {
				let chunk: StringyData | BinaryData = content;
				let encoding = "";
				let type = "";

				/*eslint prefer-rest-params: 0*/
				if (arguments.length === 2) {
					if (
						typeof arguments[0] !== "number" &&
						typeof arguments[1] === "number"
					) {
						Deprecate.deprecate(
							"res.send(body, status): Use res.status(status).send(body) instead",
						);
						proxy.statusCode = arguments[1];
					} else {
						Deprecate.deprecate(
							"res.send(status, body): Use res.status(status).send(body) instead",
						);
						proxy.statusCode = arguments[0];
						chunk = arguments[1];
					}
				}

				if (typeof chunk === "number" && arguments.length === 1) {
					if (!proxy.get("Content-Type")) proxy.type("txt");

					Deprecate.deprecate(
						"res.send(status): Use res.sendStatus(status) instead",
					);
					proxy.statusCode = chunk;
					chunk = Statuses.status(chunk);
				}

				switch (typeof chunk) {
					case "string":
						if (!serverResponseMethods.get("Content-Type"))
							serverResponseMethods.type("html");
						break;
					case "boolean":
					case "number":
					case "object":
						if (Utils.isVoid(chunk)) chunk = "";
						else if (typeof chunk === "object" && "buffer" in chunk) {
							if (!serverResponseMethods.get("Content-Type"))
								serverResponseMethods.type("bin");
						} else return serverResponseMethods.json(chunk);
						break;
				}

				if (typeof chunk === "string") {
					encoding = "utf-8";
					type = serverResponseMethods.get("Content-Type");

					if (typeof type === "string") {
						serverResponseMethods.set(
							"Content-Type",
							Charset.get(type, "utf-8"),
						);
					}
				}

				if (proxy.method === "HEAD") serverResponseMethods.end();
				else
					serverResponseMethods.end(
						chunk,
						(encoding as BinaryEncoding) ?? "utf-8",
					);

				return proxy;
			},
			json: (content: StringyData): ServerResponse => {
				let val: StringyData = JSON.parse(JSON.stringify(content));

				if (arguments.length === 2) {
					if (typeof arguments[1] === "number") {
						Deprecate.deprecate(
							"res.json(obj, status): Use res.status(status).json(obj) instead",
						);
						proxy.statusCode = arguments[1];
					}
				} else {
					Deprecate.deprecate(
						"res.json(status, obj): Use res.status(status).json(obj) instead",
					);
					proxy.statusCode = arguments[0];
					val = arguments[1];
				}

				const body: string = StringyDataParser.stringify(val);

				if (!serverResponseMethods.get("Content-Type"))
					serverResponseMethods.set("Content-Type", "application/json");

				return serverResponseMethods.send(body);
			},
			jsonp: (content: StringyData) => {
				return serverResponseMethods.json(content);
			},
			sendStatus: (statusCode: number): ServerResponse => {
				proxy.statusCode = statusCode;

				return proxy;
			},
			contentType: (type: string): ServerResponse => {
				return proxy.type(type);
			},
			type: (type: string): ServerResponse => {
				const contentType: string = ~type.indexOf("/")
					? (Charset.lookup(type) as string)
					: type;

				return proxy.set("Content-Type", contentType);
			},
			append: (field: string, value: string | string[]): ServerResponse => {
				if (Array.isArray(value))
					for (const header of value) response.headers.append(field, header);
				else response.headers.append(field, value);

				return proxy;
			},
			set: (
				field: string | Record<string, string>,
				value?: string | string[],
			): ServerResponse => {
				return serverResponseMethods.header(field, value);
			},
			header: (
				field: string | Record<string, string>,
				value?: string | string[],
			): ServerResponse => {
				const charsetRegex = /;\s*charset\s*=/;

				if (typeof field === "string") {
					let headerValue: string;

					if (Array.isArray(value)) headerValue = value.join(", ");
					else headerValue = value as string;

					if (field.toLowerCase() === "content-type")
						if (Array.isArray(value))
							throw new TypeError("Content-Type cannot be set to an Array");

					if (!charsetRegex.test((value as string) ?? "")) {
						const charset: string | undefined = Charset.lookup(
							(value as string).split(";")[0],
						);

						if (!Utils.isVoid(charset))
							headerValue += `; charset=${charset.toLowerCase()}`;
					}

					response.headers.set("field", headerValue);
				} else for (const key in field) response.headers.set(key, field[key]);

				return proxy;
			},
			get: (field: string): string => {
				return response.headers.get(field) ?? "";
			},
			location: (url: string): ServerResponse => {
				let location: string = url;

				if (url === "back")
					location = serverResponseMethods.get("Referrer") || "/";

				return serverResponseMethods.set("Location", encodeURI(location));
			},
			end: (
				content?: StringyData | BinaryData,
				encoding?: BinaryEncoding,
			): ServerResponse => {
				if (!Utils.isVoid(content)) proxy.body = content;
				serverResponseMethods.header("Content-Encoding", encoding ?? "utf-8");

				proxy.writableEnded = true;

				return proxy;
			},
			format: (): ServerResponse => {
				Deprecate.deprecate("res.format(obj): Not implemented");

				return proxy;
			},
			redirect: (): void => {
				Deprecate.deprecate("res.redirect(url): Not implemented");

				return;
			},
			vary: (): ServerResponse => {
				Deprecate.deprecate("res.vary(field): Unsupported");

				return proxy;
			},
			clearCookie: (): ServerResponse => {
				Deprecate.deprecate("res.cookie(name, options): Unsupported");

				return proxy;
			},
			cookie: (): ServerResponse => {
				Deprecate.deprecate("res.cookie(name, value, options): Unsupported");

				return proxy;
			},
			attachment: (): ServerResponse => {
				Deprecate.deprecate("res.attachment(filename): Unsupported");

				return proxy;
			},
			sendFile: (): void => {
				Deprecate.deprecate("res.sendFile(path, options): Unsupported");

				return;
			},
			sendfile: (): void => {
				Deprecate.deprecate("res.sendfile(path, options): Unsupported");

				return;
			},
			download: (): void => {
				Deprecate.deprecate(
					"res.download(path, filename, options): Unsupported",
				);

				return;
			},
			render: (): void => {
				Deprecate.deprecate("res.render(view, options, callback): Unsupported");

				return;
			},
		};
		const serverResponse: Record<string, any> = { ...serverResponseMethods };

		const otherProperties: Record<string, any> = Object.create(null);

		const proxy: unknown & ServerResponse = new Proxy(Object.create(null), {
			get: (_, property: string): any => {
				Utils.defineGetter(
					serverResponse,
					"headers",
					(): Record<string, string> => {
						const headers: Record<string, string> = Object.create(null);

						if ("headers" in otherProperties) return otherProperties.headers;

						if (!("headers" in response)) return headers;

						response?.headers?.forEach((value: string, header: string) => {
							headers[header] = value;
						});

						otherProperties.headers = headers;

						return headers;
					},
				);

				return serverResponse[property] ?? otherProperties[property];
			},
			set: (_, property: string, value: any): boolean => {
				if (!(property in serverResponseMethods))
					return (otherProperties[property] = value), true;

				return false;
			},
		});

		return Object.freeze(proxy);
	};
}

/**
 * Use a ServerResponse object in place of a Fetch Response object
 *
 * @param {ServerResponse} serverResponse the ServerResponse object
 * @returns a Fetch Response object
 */
export function useServerResponse(
	serverResponse: unknown & ServerResponse,
): Response {
	const response: Response = new Response(useBody(serverResponse.body), {
		status: serverResponse?.statusCode ?? 200,
		statusText: (StatusCodes as any)[
			serverResponse?.statusCode?.toString() ?? "200"
		],
		headers: new Headers(serverResponse.headers),
	});

	const fetchResponseMethods: Record<string, any> = {
		arrayBuffer: async (): Promise<ArrayBuffer | void> => {
			if (Utils.isVoid(serverResponse?.body)) return;

			return response.arrayBuffer();
		},
		blob: async (): Promise<Blob | void> => {
			if (Utils.isVoid(serverResponse?.body)) return;

			return response?.blob();
		},
		clone: (): Response => {
			return { ...response };
		},
		formData: async (): Promise<FormData | void> => {
			if (Utils.isVoid(serverResponse?.body)) return;

			return response?.formData();
		},
		json: async (): Promise<Record<string, any> | void> => {
			if (Utils.isVoid(serverResponse?.body)) return;

			return response?.json();
		},
		text: async (): Promise<string | void> => {
			if (Utils.isVoid(serverResponse?.body)) return;

			return response?.text();
		},
	};
	const fetchResponse: Record<string, any> = { ...fetchResponseMethods };

	const otherProperties: Record<string, any> = Object.create(null);

	const proxy: Response = new Proxy(Object.create(null), {
		get: (_, property: string): any => {
			return (
				fetchResponse[property] ??
				otherProperties[property] ??
				response[property as keyof Response]
			);
		},
		set: (_, property: string, value: string): boolean => {
			if (!(property in serverResponse))
				return (otherProperties[property] = value), true;

			return true;
		},
	});

	return Object.freeze(proxy);
}

export function useBody(body: StringyData | BinaryData | undefined): BodyInit {
	return body?.toString() ?? "";
}
