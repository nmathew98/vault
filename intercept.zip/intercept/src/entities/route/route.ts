import type { ServerRequest } from "../shared/types/request";
import type { ServerResponse } from "../shared/types/response";
import Utils from "../shared/utils";

export interface Route {
	/**
	 * Get the handler associated with a route
	 *
	 * @param {string} route the route
	 * @returns {RouteHandler[] | void} the handlers associated with the route or void if not
	 */
	getHandlers: (route: string) => RouteHandler[] | void;
	/**
	 * Get the parameters associated with a route
	 *
	 * Route parameters are returned as an object with the keys being the route parameters
	 * name and its value the value from the `route` parameter.
	 *
	 * For example, calling this method with the following route:
	 * 		/book/:id
	 * with `route = /book/3` will return:
	 * 		`{ 'id': '3' }`
	 *
	 * @param {string} route the route
	 * @returns {RouteParameters} the parameters associated with the route or an empty object if not
	 */
	getParameters: (route: string) => RouteParameters;
	/**
	 * Add a route and associated handlers
	 *
	 * Routes start with a forward slash and have no trailing slash, with route parameters
	 * being prefixed by a colon.
	 *
	 * The following are valid routes:
	 * 		/book
	 * 		/book/:id (The route parameter is id)
	 *
	 * Routes are matched structurally, for example the following routes are the same:
	 * 		/book/:id
	 * 		/book/:title
	 *
	 * Adding a route which has the same structure as an existing one will update the
	 * route parameters key to match that of the new one. For example:
	 *		route.add('/book/:id', firstHandler)
	 * 		route.add('/book/:title', secondHandler)
	 * 		// The route parameter id will be renamed to title
	 *
	 * A route can have one or more handlers, adding a handler to an existing route will
	 * append that handler to the end of the routes current set of handlers. If there are
	 * multiple handlers for a route, each handler must take a `next` parameter and call
	 * it at the end.
	 *
	 * @param {string} route the route
	 * @param {RouteHandler} handler the handlers associated with the route
	 * @returns {Route} Route object for chaining
	 */
	add: (route: string, handler: RouteHandler) => Route;
	/**
	 * Remove a route and its handlers
	 *
	 * @param {string} route the route
	 * @returns {Route} Route object for chaining
	 */
	remove: (route: string) => Route;
}

interface RouteInternals {
	_routes: Routes;
}

export interface Routes {
	[route: string]: RouteHandler[];
}

export interface RouteParameters {
	[key: string]: string;
}

export interface RouteHandler {
	(
		request: ServerRequest,
		response: ServerResponse,
		next?: (...args: any[]) => void,
	): Promise<any>;
}

export function makeRoute(): Route {
	const internals: RouteInternals = { _routes: Object.create(null) };

	return Object.freeze({
		getHandlers: (route: string): RouteHandler[] | void => {
			if (Utils.isVoid(route)) return;

			const handlers: RouteHandler[] = [];

			if ("*" in internals._routes) handlers.push(...internals._routes["*"]);

			const matchingRoute: string = getMatchingRoute(
				route,
				Object.keys(internals._routes),
			);
			if (matchingRoute in internals._routes)
				handlers.push(...internals._routes[matchingRoute]);

			return handlers;
		},
		getParameters: (route: string): RouteParameters => {
			const routeParameters: RouteParameters = Object.create(null);

			const matchingRoute: string = getMatchingRoute(
				route,
				Object.keys(internals._routes),
			);

			const splitOriginalRoute: string[] = route.split("/");
			const splitMatchingRoute: string[] = matchingRoute.split("/");
			if (splitOriginalRoute.length === splitMatchingRoute.length)
				for (const [index, matchingRoute] of splitMatchingRoute.entries())
					if (hasRouteParameter(matchingRoute))
						routeParameters[getRouteParameterName(matchingRoute)] =
							splitOriginalRoute[index];

			return routeParameters;
		},
		add(route: string, handler: RouteHandler | RouteHandler[]): Route {
			if (!Utils.isVoid(route) && !Utils.isVoid(handler)) {
				const matchingRoute: string = getMatchingRoute(
					route,
					Object.keys(internals._routes),
				);

				internals._routes[route] = (
					internals._routes[matchingRoute || route] ?? []
				).concat(handler);

				if (hasRouteParameter(route) && matchingRoute !== route)
					delete internals._routes[matchingRoute];
			}

			return this;
		},
		remove(route: string): Route {
			const matchingRoute: string = getMatchingRoute(
				route,
				Object.keys(internals._routes),
			);
			if (matchingRoute in internals._routes)
				delete internals._routes[matchingRoute];

			return this;
		},
	});
}

/* istanbul ignore next */
function getNumberOfSlashesInRoute(route: string): number {
	return route.match(/[/]/g)?.length ?? 0;
}

/* istanbul ignore next */
function getBaseRoute(route: string): string {
	return (
		route
			.match(/[/][A-Za-z0-9_]+/)
			?.map((route: string) => route.replace("/", ""))
			?.pop() ?? ""
	);
}

/* istanbul ignore next */
function getMatchingRoute(route: string, routes: string[]): string {
	const numberOfSlashesInRoute: number = getNumberOfSlashesInRoute(route);
	const baseRoute: string = getBaseRoute(route);

	const matchingRoute: string =
		routes
			.filter(
				(route: string) =>
					getNumberOfSlashesInRoute(route) === numberOfSlashesInRoute &&
					getBaseRoute(route) === baseRoute,
			)
			?.pop() ?? "";

	return matchingRoute;
}

/* istanbul ignore next */
function getRouteParameterName(route: string): string {
	return route.match(/:([A-Za-z0-9_]+)/)?.pop() ?? "";
}

/* istanbul ignore next */
function hasRouteParameter(route: string): boolean {
	return /:([A-Za-z0-9_]+)/.test(route);
}
