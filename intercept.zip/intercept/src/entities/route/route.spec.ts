import { makeRoute, RouteHandler, Route, RouteParameters } from "./route";

describe("Route", () => {
	let route: Route;

	beforeEach(() => {
		route = makeRoute();
	});

	describe("getHandlers", () => {
		it("returns void if path is undefined", () => {
			const handlers: RouteHandler[] | void = route.getHandlers(
				undefined as unknown as string,
			);

			expect(handlers).toStrictEqual(undefined);
		});

		it("returns the handlers associated with a path", () => {
			const firstHandler: RouteHandler = jest.fn();
			const secondHandler: RouteHandler = jest.fn();
			const thirdHandler: RouteHandler = jest.fn();

			route.add("/hello", firstHandler);
			route.add("/hello", secondHandler);
			route.add("/hello", thirdHandler);

			const handlers: RouteHandler[] | void = route.getHandlers("/hello");

			expect(handlers).not.toStrictEqual(undefined);
			expect(handlers?.length).toStrictEqual(3);
		});

		it("returns the correct handlers associated with a path if it has route parameters", () => {
			const firstHandler: RouteHandler = jest.fn();
			const secondHandler: RouteHandler = jest.fn();
			const thirdHandler: RouteHandler = jest.fn();

			route.add("/hello/:test", firstHandler);
			route.add("/hello/:test", secondHandler);
			route.add("/hello/:test", thirdHandler);

			const handlers: RouteHandler[] | void = route.getHandlers("/hello/world");

			expect(handlers).not.toStrictEqual(undefined);
			expect(handlers?.length).toStrictEqual(3);
		});

		it("returns any wildcard handlers in addition to handlers for the path", () => {
			const firstHandler: RouteHandler = jest.fn();
			const secondHandler: RouteHandler = jest.fn();
			const thirdHandler: RouteHandler = jest.fn();

			route.add("*", firstHandler);
			route.add("/hello", secondHandler);
			route.add("/hello", thirdHandler);

			const handlersForFirstPath: RouteHandler[] | void =
				route.getHandlers("/hello");
			const handlersForSecondPath: RouteHandler[] | void =
				route.getHandlers("/world");

			expect(handlersForFirstPath).not.toStrictEqual(undefined);
			expect(handlersForFirstPath?.length).toStrictEqual(3);

			expect(handlersForSecondPath).not.toStrictEqual(undefined);
			expect(handlersForSecondPath?.length).toStrictEqual(1);
		});
	});

	describe("getParameters", () => {
		it("returns an object containing a routes parameters if it has any", () => {
			const firstHandler: RouteHandler = jest.fn();
			const secondHandler: RouteHandler = jest.fn();
			const thirdHandler: RouteHandler = jest.fn();

			route.add("/hello/:test", firstHandler);
			route.add("/hello/:test", secondHandler);
			route.add("/hello/:test", thirdHandler);

			const routeParameters: RouteParameters =
				route.getParameters("/hello/world");
			expect(Object.keys(routeParameters).length).toStrictEqual(1);
			expect(routeParameters["test"]).toStrictEqual("world");

			const noRouteParameters: RouteParameters =
				route.getParameters("/hello/world/again");
			expect(Object.keys(noRouteParameters).length).toStrictEqual(0);
		});
	});

	describe("add", () => {
		it("returns a Route object if parameters are not undefined", () => {
			const firstHandler: RouteHandler = jest.fn();

			const result: Route = route.add("/hello", firstHandler);

			expect("getHandlers" in result).toStrictEqual(true);
			expect("add" in result).toStrictEqual(true);
			expect("remove" in result).toStrictEqual(true);
		});

		it("returns a Route object if parameters are undefined", () => {
			const result: Route = route.add(
				undefined as unknown as string,
				undefined as unknown as RouteHandler,
			);

			expect("getHandlers" in result).toStrictEqual(true);
			expect("add" in result).toStrictEqual(true);
			expect("remove" in result).toStrictEqual(true);
		});

		it("adds a route based on the number of slashes and the base path and updates the route parameters name", () => {
			const firstHandler: RouteHandler = jest.fn();
			const secondHandler: RouteHandler = jest.fn();
			const thirdHandler: RouteHandler = jest.fn();

			route.add("/hello/:test", firstHandler);
			route.add("/hello/:x", secondHandler);
			route.add("/hello/:y", thirdHandler);

			const handlers: RouteHandler[] | void = route.getHandlers("/hello/world");

			expect(handlers).not.toStrictEqual(undefined);
			expect(handlers?.length).toStrictEqual(3);

			const routeParameters: RouteParameters =
				route.getParameters("/hello/world");

			expect(Object.keys(routeParameters).length).toStrictEqual(1);
			expect(routeParameters["y"]).toStrictEqual("world");
		});
	});

	describe("remove", () => {
		it("removes a path and its associated handler", () => {
			const firstHandler: RouteHandler = jest.fn();

			route.add("/hello", firstHandler);

			route.remove("/hello");

			const result: RouteHandler[] | void = route.getHandlers("/hello");

			expect(result?.length).toStrictEqual(0);
		});
	});
});
