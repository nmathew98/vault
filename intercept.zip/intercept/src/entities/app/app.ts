import type { ServerRequest } from "../shared/types/request";
import type { ServerResponse } from "../shared/types/response";
import type { ServerResponsePackages } from "../response/response";
import type { URLParser, ParsedURL } from "../shared/packages/url";
import type { Logger } from "../shared/packages/logger";
import {
	buildMakeServerRequest,
	ServerRequestPackages,
} from "../request/request";
import { makeRoute, RouteHandler, Route } from "../route/route";
import {
	buildMakeServerResponse,
	useServerResponse,
} from "../response/response";
import Utils from "../shared/utils";

export interface App {
	/**
	 * Calls the handler(s) associated with the requests route with handlers
	 * being automatically promisified
	 *
	 * If an error is thrown anywhere within the middleware stack, an error will
	 * be logged. The app will not crash.
	 *
	 * @param {Request} request the request
	 * @returns {Response} a Fetch Response object
	 */
	handle: (request: Request) => Promise<Response>;
	/**
	 * Use a middleware to handle a route or to handle all routes
	 *
	 * The following are all valid middleware function types:
	 * 		(route: string, handler: RouteHandler) => App
	 * 		(route: string, handlers: RouteHandler[]) => App
	 * 		(routes: string, handlers: RouteHandler[]) => App
	 * 		(handler: RouteHandler) => App
	 * 		(handlers: RouteHandler[]) => App
	 *
	 * Using a middleware without a specified route will make that middleware
	 * apply to all routes
	 */
	use: Middleware;
}

interface AppInternals {
	_routes: Route;
}

export interface Middleware {
	(route: string, handler: RouteHandler): App;
	(route: string, handlers: RouteHandler[]): App;
	(routes: string[], handlers: RouteHandler[]): App;
	(handler: RouteHandler): App;
	(handlers: RouteHandler[]): App;
}

export interface AppConfiguration {
	serverRequest: ServerRequestPackages;
	serverResponse: ServerResponsePackages;
	routes?: Route;
}

export interface AppPackages {
	URLParser: URLParser;
	Logger: Logger;
}

export function buildMakeApp({ URLParser, Logger }: AppPackages) {
	return function makeApp(configuration: AppConfiguration): App {
		const internals: AppInternals = {
			_routes: configuration.routes ?? makeRoute(),
		};

		return Object.freeze({
			handle: async (request: Request): Promise<Response> => {
				const parsedUrl: Partial<ParsedURL> = URLParser.parse(request.url);

				const makeServerRequest = buildMakeServerRequest(
					configuration.serverRequest,
				);
				const makeServerResponse = buildMakeServerResponse(
					configuration.serverResponse,
				);

				const serverRequest: ServerRequest = makeServerRequest(request);
				const serverResponse: ServerResponse = makeServerResponse(
					new Response(),
				);

				if (!Utils.isVoid(parsedUrl.pathname)) {
					const handlers: RouteHandler[] | void = internals._routes.getHandlers(
						parsedUrl.pathname as string,
					);

					try {
						if (!Utils.isVoid(handlers))
							if (handlers.length === 1)
								await (handlers.pop() as RouteHandler)(
									serverRequest,
									serverResponse,
								);
							else if (handlers.length > 1)
								await handlers.reduce(
									(handlers: Promise<unknown>, handler: RouteHandler) =>
										handlers.then(
											() =>
												new Promise((next: any) =>
													!serverResponse.writableEnded
														? handler(serverRequest, serverResponse, next)
														: next(),
												),
										),
									Promise.resolve(),
								);
					} catch (error: any) {
						Logger.error(`Unexpected error occured: ${error.message}`);
					}
				}

				return useServerResponse(serverResponse);
			},
			use(...args: any[]): App {
				if (isString(args[0]) && isRouteHandler(args[1]))
					internals._routes.add(args[0], args[1]);
				else if (isString(args[0]) && isRouteHandlerArray(args[1]))
					for (let i = 0; i < args[1].length; i++)
						internals._routes.add(args[0], args[1][i]);
				else if (
					isStringArray(args[0]) &&
					isRouteHandlerArray(args[1]) &&
					args[0].length === args[1].length
				)
					for (let i = 0; i < args[0].length; i++)
						internals._routes.add(args[0][i], args[1][i]);
				else if (isRouteHandler(args[0])) internals._routes.add("*", args[0]);
				else if (isRouteHandlerArray(args[0]))
					for (let i = 0; i < args[0].length; i++)
						internals._routes.add("*", args[0][i]);

				return this;
			},
		});
	};
}

function isString(x: any): x is string {
	return !Array.isArray(x) && typeof x === "string";
}

function isRouteHandler(x: any): x is RouteHandler {
	return !Array.isArray(x) && typeof x === "function";
}

function isStringArray(x: any): x is string[] {
	return Array.isArray(x) && x.length > 0 && typeof x[0] === "string";
}

function isRouteHandlerArray(x: any): x is RouteHandler[] {
	return Array.isArray(x) && x.length > 0 && typeof x[0] === "function";
}
