import type { URLParser } from "../shared/packages/url";
import type { RouteHandler, Route } from "../route/route";
import type { AcceptParser } from "../shared/packages/accept-parser";
import type { Deprecate } from "../shared/packages/deprecate";
import type { RangeParser } from "../shared/packages/range-parser";
import type { Statuses } from "../shared/packages/statuses";
import type { Charset } from "../shared/packages/charset";
import type { StringyDataParser } from "../shared/packages/data-parser";
import type { ServerResponse } from "../shared/types/response";
import type { Logger } from "../shared/packages/logger";
import { App, AppConfiguration, buildMakeApp } from "./app";

describe("App", () => {
	let route: Route;
	let URLParser: URLParser;
	let AcceptParser: AcceptParser;
	let Deprecate: Deprecate;
	let RangeParser: RangeParser;
	let Statuses: Statuses;
	let Charset: Charset;
	let StringyDataParser: StringyDataParser;
	let Logger: Logger;
	let appConfiguration: AppConfiguration;
	let makeApp: any;

	beforeEach(() => {
		const routes: Record<string, any> = {};

		route = {
			getHandlers: jest.fn().mockImplementation((path: string) => {
				return routes[path] ?? [];
			}),
			add: jest
				.fn()
				.mockImplementation((path: string, handler: RouteHandler) => {
					routes[path] = [...(routes[path] ?? []), handler];
				}),
			remove: jest.fn(),
			getParameters: jest.fn(),
		};

		global.Request = jest.fn().mockImplementation((url: string) => ({ url }));
		global.Response = jest.fn() as any;
		global.Headers = jest.fn();

		URLParser = {
			match: jest.fn(),
			parse: jest.fn().mockImplementation(() => ({ pathname: "/hello" })),
		};
		AcceptParser = jest.fn() as any;
		Deprecate = jest.fn() as any;
		RangeParser = jest.fn() as any;
		Statuses = jest.fn() as any;
		Charset = jest.fn() as any;
		StringyDataParser = jest.fn() as any;
		Logger = {
			debug: jest.fn(),
			error: jest.fn(),
			info: jest.fn(),
		};

		appConfiguration = {
			serverRequest: {
				AcceptParser,
				Deprecate,
				RangeParser,
				URLParser,
			},
			serverResponse: {
				URLParser,
				Deprecate,
				Statuses,
				Charset,
				StringyDataParser,
			},
			routes: route,
		};

		makeApp = buildMakeApp({ URLParser, Logger });
	});

	describe("use", () => {
		it("accepts a route and a handler", () => {
			const handler: RouteHandler = jest.fn();

			const app: App = makeApp(appConfiguration);

			app.use("/test", handler);

			expect(route.add).toBeCalledTimes(1);
		});

		it("creates a new Route object if there is none provided", () => {
			const appConfiguration = {
				serverRequest: {
					AcceptParser,
					Deprecate,
					RangeParser,
					URLParser,
				},
				serverResponse: {
					URLParser,
					Deprecate,
					Statuses,
					Charset,
					StringyDataParser,
				},
			};

			const handler: RouteHandler = jest.fn();

			const app: App = makeApp(appConfiguration);

			app.use("/hello", handler);

			app.handle(new Request("/hello"));

			expect(handler).toBeCalledTimes(1);
		});

		it("accepts a route and an array of handlers", () => {
			const handlers: RouteHandler[] = [jest.fn(), jest.fn()];

			const app: App = makeApp(appConfiguration);

			app.use("/test", handlers);

			expect(route.add).toBeCalledTimes(2);
		});

		it("accepts an array of routes and an array of handlers", () => {
			const paths: string[] = ["/hello", "/world"];
			const handlers: RouteHandler[] = [jest.fn(), jest.fn()];

			const app: App = makeApp(appConfiguration);
			app.use(paths, handlers);

			expect(route.add).toBeCalledTimes(2);
		});

		it("accepts a wildcard handler", () => {
			const handler: RouteHandler = jest.fn();

			const app: App = makeApp(appConfiguration);
			app.use(handler);

			expect(route.add).toBeCalledTimes(1);
		});

		it("accepts a wildcard array of handlers", () => {
			const handlers: RouteHandler[] = [jest.fn(), jest.fn()];

			const app: App = makeApp(appConfiguration);
			app.use(handlers);

			expect(route.add).toBeCalledTimes(2);
		});
	});

	describe("handle", () => {
		it("handles errors gracefully", async () => {
			const firstMiddleware: RouteHandler = async (): Promise<any> => {
				throw new Error("Hello world!");
			};

			const app: App = makeApp(appConfiguration);
			app.use("/hello", firstMiddleware);

			await app.handle(new Request("/hello"));

			expect(Logger.error).toBeCalledTimes(1);
		});

		it("calls a middleware", async () => {
			let firstMiddlewareCalledAt = -1;
			const firstMiddleware: RouteHandler = async (): Promise<any> => {
				firstMiddlewareCalledAt = Date.now();
			};

			const app: App = makeApp(appConfiguration);
			app.use("/hello", firstMiddleware);

			await app.handle(new Request("/hello"));

			expect(firstMiddlewareCalledAt).not.toStrictEqual(-1);
		});

		it("calls the middleware in sequence", async () => {
			let firstMiddlewareCalledAt = -1;
			const firstMiddleware: RouteHandler = async (
				_1,
				_2,
				next?: () => void,
			): Promise<any> => {
				firstMiddlewareCalledAt = Date.now();

				setTimeout(() => {
					if (next !== undefined) next();
				}, 10);
			};

			let secondMiddlewareCalledAt = -1;
			const secondMiddleware: RouteHandler = async (
				_1,
				_2,
				next?: () => void,
			): Promise<any> => {
				secondMiddlewareCalledAt = Date.now();

				if (next !== undefined) next();
			};

			const sequence: RouteHandler[] = [firstMiddleware, secondMiddleware];

			const app: App = makeApp(appConfiguration);
			app.use("/hello", sequence);

			await app.handle(new Request("/hello"));

			expect(firstMiddlewareCalledAt < secondMiddlewareCalledAt).toStrictEqual(
				true,
			);
		});

		it("does not call the next middleware if writableEnded is set", async () => {
			let firstMiddlewareCalledAt = -1;
			const firstMiddleware: RouteHandler = async (
				_1,
				response: ServerResponse,
				next?: () => void,
			): Promise<any> => {
				firstMiddlewareCalledAt = Date.now();

				response.writableEnded = true;

				setTimeout(() => {
					if (next !== undefined) next(), 10;
				});
			};

			let secondMiddlewareCalledAt = -1;
			const secondMiddleware: RouteHandler = async (
				_1,
				_2,
				next?: () => void,
			): Promise<any> => {
				secondMiddlewareCalledAt = Date.now();

				if (next !== undefined) next();
			};

			const sequence: RouteHandler[] = [firstMiddleware, secondMiddleware];

			const app: App = makeApp(appConfiguration);
			app.use("/hello", sequence);

			await app.handle(new Request("/hello"));

			expect(firstMiddlewareCalledAt > -1).toStrictEqual(true);
			expect(secondMiddlewareCalledAt).toStrictEqual(-1);
		});
	});
});
