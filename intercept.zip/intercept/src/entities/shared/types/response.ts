import type { StatusCodes } from "../status-codes";
import type { StringyData, BinaryEncoding } from "../packages/data-parser";

/**
 * Based on Express' Response and Node's ServerResponse
 *
 * Docs and implementation adapted from Express
 */
export interface ServerResponse {
	/**
	 * Set status `code`.
	 *
	 * @param {number} code the status code to set
	 * @returns {ServerResponse}
	 */
	status: (code: number) => ServerResponse;
	/**
	 * Set Link header field with the given `links`.
	 *
	 * Examples:
	 *
	 *    res.links({
	 *      next: 'http://api.example.com/users?page=2',
	 *      last: 'http://api.example.com/users?page=5'
	 *    });
	 *
	 * @param {Object} links
	 * @return {ServerResponse}
	 * @public
	 */
	links: (links: Record<string, string>) => ServerResponse;
	/**
	 * Send a response.
	 * Accepts any object with a toString() method
	 *
	 * Examples:
	 *
	 *     res.send(Buffer.from('wahoo'));
	 *     res.send({ some: 'json' });
	 *     res.send('<p>some html</p>');
	 *
	 * @param {StringyData | BinaryData} body
	 * @public
	 */
	send: (content: StringyData | BinaryData) => ServerResponse;
	/**
	 * Send JSON response.
	 * Accepts any object with a toString() method
	 *
	 * Examples:
	 *
	 *     res.json(null);
	 *     res.json({ user: 'tj' });
	 *
	 * @param {StringyData} obj
	 * @public
	 */
	json: (content: StringyData) => ServerResponse;
	/**
	 * Unsupported method
	 */
	jsonp: (content: StringyData) => ServerResponse;
	/**
	 * Send given HTTP status code.
	 *
	 * Sets the response status to `statusCode` and the body of the
	 * response to the standard description from node's http.STATUS_CODES
	 * or the statusCode number if no description.
	 *
	 * Examples:
	 *
	 *     res.sendStatus(200);
	 *
	 * @param {number} statusCode
	 * @public
	 */
	sendStatus: (statusCode: number) => ServerResponse;
	/**
	 * Set _Content-Type_ response header with `type` through `mime.lookup()`
	 * when it does not contain "/", or set the Content-Type to `type` otherwise.
	 *
	 * Examples:
	 *
	 *     res.type('.html');
	 *     res.type('html');
	 *     res.type('json');
	 *     res.type('application/json');
	 *     res.type('png');
	 *
	 * @param {String} type
	 * @return {ServerResponse} for chaining
	 * @public
	 */
	contentType: (type: string) => ServerResponse;
	/**
	 * Set _Content-Type_ response header with `type` through `mime.lookup()`
	 * when it does not contain "/", or set the Content-Type to `type` otherwise.
	 *
	 * Examples:
	 *
	 *     res.type('.html');
	 *     res.type('html');
	 *     res.type('json');
	 *     res.type('application/json');
	 *     res.type('png');
	 *
	 * @param {String} type
	 * @return {ServerResponse} for chaining
	 * @public
	 */
	type: (type: string) => ServerResponse;
	/**
	 * Not implemented yet
	 *
	 * Respond to the Acceptable formats using an `obj`
	 * of mime-type callbacks.
	 *
	 * This method uses `req.accepted`, an array of
	 * acceptable types ordered by their quality values.
	 * When "Accept" is not present the _first_ callback
	 * is invoked, otherwise the first match is used. When
	 * no match is performed the server responds with
	 * 406 "Not Acceptable".
	 *
	 * Content-Type is set for you, however if you choose
	 * you may alter this within the callback using `res.type()`
	 * or `res.set('Content-Type', ...)`.
	 *
	 *    res.format({
	 *      'text/plain': function(){
	 *        res.send('hey');
	 *      },
	 *
	 *      'text/html': function(){
	 *        res.send('<p>hey</p>');
	 *      },
	 *
	 *      'application/json': function () {
	 *        res.send({ message: 'hey' });
	 *      }
	 *    });
	 *
	 * In addition to canonicalized MIME types you may
	 * also use extnames mapped to these types:
	 *
	 *    res.format({
	 *      text: function(){
	 *        res.send('hey');
	 *      },
	 *
	 *      html: function(){
	 *        res.send('<p>hey</p>');
	 *      },
	 *
	 *      json: function(){
	 *        res.send({ message: 'hey' });
	 *      }
	 *    });
	 *
	 * By default Express passes an `Error`
	 * with a `.status` of 406 to `next(err)`
	 * if a match is not made. If you provide
	 * a `.default` callback it will be invoked
	 * instead.
	 *
	 * @param {Object} obj
	 * @return {ServerResponse} for chaining
	 * @public
	 */
	format: (object: Record<string, string>) => ServerResponse;
	/**
	 * Append additional header `field` with value `val`.
	 *
	 * Example:
	 *
	 *    res.append('Link', ['<http://localhost/>', '<http://localhost:3000/>']);
	 *    res.append('Set-Cookie', 'foo=bar; Path=/; HttpOnly');
	 *    res.append('Warning', '199 Miscellaneous warning');
	 *
	 * @param {String} field
	 * @param {String|Array} val
	 * @return {ServerResponse} for chaining
	 * @public
	 */
	append: (field: string, value: string | string[]) => ServerResponse;
	/**
	 * Set header `field` to `val`, or pass
	 * an object of header fields.
	 *
	 * Examples:
	 *
	 *    res.set('Foo', ['bar', 'baz']);
	 *    res.set('Accept', 'application/json');
	 *    res.set({ Accept: 'text/plain', 'X-API-Key': 'tobi' });
	 *
	 * Aliased as `res.header()`.
	 *
	 * @param {String|Object} field
	 * @param {String|Array} val
	 * @return {ServerResponse} for chaining
	 * @public
	 */
	set: (
		field: string | Record<string, string>,
		value?: string | string[],
	) => ServerResponse;
	/**
	 * Set header `field` to `val`, or pass
	 * an object of header fields.
	 *
	 * Examples:
	 *
	 *    res.set('Foo', ['bar', 'baz']);
	 *    res.set('Accept', 'application/json');
	 *    res.set({ Accept: 'text/plain', 'X-API-Key': 'tobi' });
	 *
	 * Aliased as `res.header()`.
	 *
	 * @param {String|Object} field
	 * @param {String|Array} val
	 * @return {ServerResponse} for chaining
	 * @public
	 */
	header: (
		field: string | Record<string, string>,
		value?: string | string[],
	) => ServerResponse;
	/**
	 * Get value for header `field`.
	 *
	 * @param {String} field
	 * @return {String}
	 * @public
	 */
	get: (field: string) => string;
	/**
	 * Set the location header to `url`.
	 *
	 * The given `url` can also be "back", which redirects
	 * to the _Referrer_ or _Referer_ headers or "/".
	 *
	 * Examples:
	 *
	 *    res.location('/foo/bar').;
	 *    res.location('http://example.com');
	 *    res.location('../login');
	 *
	 * @param {String} url
	 * @return {ServerResponse} for chaining
	 * @public
	 */
	location: (url: string) => ServerResponse;
	/**
	 * Not implemented yet
	 *
	 * Redirect to the given `url` with optional response `status`
	 * defaulting to 302.
	 *
	 * The resulting `url` is determined by `res.location()`, so
	 * it will play nicely with mounted apps, relative paths,
	 * `"back"` etc.
	 *
	 * Examples:
	 *
	 *    res.redirect('/foo/bar');
	 *    res.redirect('http://example.com');
	 *    res.redirect(301, 'http://example.com');
	 *    res.redirect('../login'); // /blog/post/1 -> /blog/login
	 *
	 * @public
	 */
	redirect: (url: string) => void;
	/**
	 * The implementation of this method differs from the one in Node significantly
	 * mainly due to the fact that there is no Buffer object or Socket client side.
	 *
	 * Instead the method takes in any type of data with a toString() method for `content`.
	 * If `content` is not undefined, the ServerResponse's body property will be set to it.
	 *
	 * If an encoding type is not provided, the default is `utf-8`
	 *
	 * This method will set the writableEnded flag on ServerResponse to true, when consumed
	 * by `App`, any handlers after this method is called will have no effect.
	 *
	 * @param {StringyData | BinaryData} content the data to end the response with
	 * @param {BinaryEncoding} encoding the encoding of the data
	 *
	 * @returns a ServerResponse object for chaining
	 */
	end: (
		content?: StringyData | BinaryData,
		encoding?: BinaryEncoding,
	) => ServerResponse;
	/**
	 * Does not make sense in a pure browser context so returns the original
	 * ServerResponse object for chaining
	 */
	vary: (field: string | string[]) => ServerResponse;
	/**
	 * Does not make sense in a pure browser context so returns the original
	 * ServerResponse object for chaining
	 */
	clearCookie: (
		name: string,
		options?: Record<string, string>,
	) => ServerResponse;
	/**
	 * Does not make sense in a pure browser context so returns the original
	 * ServerResponse object for chaining
	 */
	cookie: (
		name: string,
		value: string | Record<string, string>,
		options?: Record<string, string>,
	) => ServerResponse;
	/**
	 * Does not make sense in a pure browser context so returns the original
	 * ServerResponse object for chaining
	 */
	attachment: (filename: string) => ServerResponse;
	/**
	 * Does not make sense in a pure browser context
	 */
	sendFile: (
		path: string,
		options?: Record<string, any>,
		callback?: (...args: any[]) => any,
	) => void;
	/**
	 * Does not make sense in a pure browser context
	 */
	sendfile: (
		path: string,
		options?: Record<string, any>,
		callback?: (...args: any[]) => any,
	) => void;
	/**
	 * Does not make sense in a pure browser context
	 */
	download: (
		path: string,
		filename: string,
		options?: Record<string, any>,
		callback?: (...args: any[]) => any,
	) => void;
	/**
	 * Does not make sense in a pure browser context
	 */
	render: (
		view: string,
		options?: Record<string, string>,
		callback?: (...args: any[]) => any,
	) => void;

	/**
	 * Get if the response has been written
	 */
	writableEnded?: boolean;
	/**
	 * Get the status code of the response
	 */
	statusCode?: number;
	/**
	 * Get the body of the response
	 */
	body?: StringyData | BinaryData;
	/**
	 * Get the headers from the request
	 *
	 * @return {Object} an object of the headers
	 */
	readonly headers?: Record<string, string>;
	/**
	 * Get HTTP request method
	 */
	readonly method?:
		| "GET"
		| "HEAD"
		| "POST"
		| "PUT"
		| "DELETE"
		| "CONNECT"
		| "OPTIONS"
		| "TRACE"
		| "PATCH";
}

export type HttpStatusCodes = typeof StatusCodes;
