/**
 * Based on Express' Request and Node's IncomingMessage
 *
 * Docs and implementation adapted from Express
 */
export interface ServerRequest {
	/**
	 * Return request header.
	 *
	 * The `Referrer` header field is special-cased,
	 * both `Referrer` and `Referer` are interchangeable.
	 *
	 * Examples:
	 *
	 *     req.get('Content-Type');
	 *     // => "text/plain"
	 *
	 *     req.get('content-type');
	 *     // => "text/plain"
	 *
	 *     req.get('Something');
	 *     // => undefined
	 *
	 * Aliased as `req.header()`.
	 *
	 * @param {string} name the name of the header
	 * @return {string | void} string if the header exists and void if not
	 */
	get: (name: string) => string | void;
	/**
	 * Return request header.
	 *
	 * The `Referrer` header field is special-cased,
	 * both `Referrer` and `Referer` are interchangeable.
	 *
	 * Examples:
	 *
	 *     req.get('Content-Type');
	 *     // => "text/plain"
	 *
	 *     req.get('content-type');
	 *     // => "text/plain"
	 *
	 *     req.get('Something');
	 *     // => undefined
	 *
	 * Aliased as `req.header()`.
	 *
	 * @param {string} name the name of the header
	 * @return {string | void} string if the header exists and void if not
	 */
	header: (name: string) => string | void;
	/**
	 * Check if the given `type(s)` is acceptable, returning
	 * the best match when true, otherwise `undefined`, in which
	 * case you should respond with 406 "Not Acceptable".
	 *
	 * The `type` value may be a single MIME type string
	 * such as "application/json", an extension name
	 * such as "json", a comma-delimited list such as "json, html, text/plain",
	 * an argument list such as `"json", "html", "text/plain"`,
	 * or an array `["json", "html", "text/plain"]`. When a list
	 * or array is given, the _best_ match, if any is returned.
	 *
	 * Examples:
	 *
	 *     // Accept: text/html
	 *     req.accepts('html');
	 *     // => "html"
	 *
	 *     // Accept: text/*, application/json
	 *     req.accepts('html');
	 *     // => "html"
	 *     req.accepts('text/html');
	 *     // => "text/html"
	 *     req.accepts('json, text');
	 *     // => "json"
	 *     req.accepts('application/json');
	 *     // => "application/json"
	 *
	 *     // Accept: text/*, application/json
	 *     req.accepts('image/png');
	 *     req.accepts('png');
	 *     // => undefined
	 *
	 *     // Accept: text/*;q=.5, application/json
	 *     req.accepts(['html', 'json']);
	 *     req.accepts('html', 'json');
	 *     req.accepts('html, json');
	 *     // => "json"
	 *
	 * @param {string[]} types any number of strings to check for
	 * @return {string | void} a string of the first match and void if none are found
	 */
	accepts: (...types: string[]) => string | void;
	/**
	 * Check if the given `encoding`s are accepted.
	 *
	 * @param {...string} encodings any number of strings to check for
	 * @return {string | void} a string of the first match and void if none are found
	 */
	acceptsEncoding: (...encodings: string[]) => string | void;
	/**
	 * Check if the given `encoding`s are accepted.
	 *
	 * @param {...string} encodings any number of strings to check for
	 * @return {string | void} a string of the first match and void if none are found
	 */
	acceptsEncodings: (...encodings: string[]) => string | void;
	/**
	 * Check if the given `charset`s are acceptable,
	 * otherwise you should respond with 406 "Not Acceptable".
	 *
	 * @param {...string} charsets any number of strings to check for
	 * @return {string | void} a string of the first match and void if none are found
	 */
	acceptsCharset: (...charsets: string[]) => string | void;
	/**
	 * Check if the given `charset`s are acceptable,
	 * otherwise you should respond with 406 "Not Acceptable".
	 *
	 * @param {...string} charsets any number of strings to check for
	 * @return {string | void} a string of the first match and void if none are found
	 */
	acceptsCharsets: (...charsets: string[]) => string | void;
	/**
	 * Check if the given `lang`s are acceptable,
	 * otherwise you should respond with 406 "Not Acceptable".
	 *
	 * @param {...string} languages any number of strings to check for
	 * @return {string | void} a string of the first match and void if none are found
	 */
	acceptsLanguage: (...languages: string[]) => string | void;
	/**
	 * Check if the given `lang`s are acceptable,
	 * otherwise you should respond with 406 "Not Acceptable".
	 *
	 * @param {...string} languages any number of strings to check for
	 * @return {string | void} a string of the first match and void if none are found
	 */
	acceptsLanguages: (...languages: string[]) => string | void;
	/**
	 * Parse Range header field, capping to the given `size`.
	 *
	 * Unspecified ranges such as "0-" require knowledge of your resource length. In
	 * the case of a byte range this is of course the total number of bytes. If the
	 * Range header field is not given `undefined` is returned, `-1` when unsatisfiable,
	 * and `-2` when syntactically invalid.
	 *
	 * When ranges are returned, the array has a "type" property which is the type of
	 * range that is required (most commonly, "bytes"). Each array element is an object
	 * with a "start" and "end" property for the portion of the range.
	 *
	 * The "combine" option can be set to `true` and overlapping & adjacent ranges
	 * will be combined into a single range.
	 *
	 * NOTE: remember that ranges are inclusive, so for example "Range: users=0-3"
	 * should respond with 4 users when available, not 3.
	 *
	 * @param {number} size the size of the cap
	 * @param {Object} options options for the range parser
	 * @return {Object[] | number | void}
	 * an array of subranges will be returned or negative numbers if parsing failed
	 */
	range: (
		size: number,
		options?: { combine: boolean },
	) => { start: number; end: number; index?: number }[] | number | void;
	/**
	 * Return the value of param `name` when present or `defaultValue`.
	 *
	 *  - Checks route placeholders, ex: _/user/:id_
	 *  - Checks body params, ex: id=12, {"id":12}
	 *  - Checks query string params, ex: ?id=12
	 *
	 * To utilize request bodies, `req.body`
	 * should be an object. This can be done by using
	 * the `bodyParser()` middleware.
	 *
	 * @param {string} name the string used as a key for the parameter
	 * @param {string} [defaultValue] an optional default value
	 * @return {string | void} a string of the value of the parameter or void if not
	 */
	param: (name: string, defaultValue?: string) => string | void;
	/**
	 * Check if the incoming request contains the "Content-Type"
	 * header field, and it contains the given mime `type`.
	 *
	 * Examples:
	 *
	 *      // With Content-Type: text/html; charset=utf-8
	 *      req.is('html');
	 *      req.is('text/html');
	 *      req.is('text/*');
	 *      // => true
	 *
	 *      // When Content-Type is application/json
	 *      req.is('json');
	 *      req.is('application/json');
	 *      req.is('application/*');
	 *      // => true
	 *
	 *      req.is('html');
	 *      // => false
	 *
	 * @param {...string} types any number of strings to check for
	 * @return {boolean} true if there is a match
	 */
	is: (...types: string[]) => boolean;
	/**
	 * The parsed body of the request
	 *
	 * @type {*}
	 */
	body?: any;
	/**
	 * Get the headers from the request
	 *
	 * @return {Object} an object of the headers
	 */
	readonly headers?: Record<string, string>;
	/**
	 * Get the protocol string
	 *
	 * @return {string} a string which is either 'http' or 'https'
	 */
	readonly protocol?: "http" | "https";
	/**
	 * Short-hand for:
	 *
	 *    req.protocol === 'https'
	 *
	 * @return {boolean} true if the protocol is 'https'
	 */
	readonly secure?: boolean;
	/**
	 * Gets the pathname of the URL
	 *
	 * @return {string} a string if the path is available
	 */
	readonly path?: string;
	/**
	 * Gets the host from the URL
	 *
	 * @return {string} a string if the host is available
	 */
	readonly host?: string;
	/**
	 * Gets the host from the URL
	 *
	 * @return {string} a string if the host is available and false if not
	 */
	readonly hostname?: string;
	/**
	 * Check if the request is fresh, aka
	 * Last-Modified and/or the ETag
	 * still match.
	 *
	 * Does not make sense in a pure browser context so returns true by default
	 *
	 * @return {boolean} true
	 */
	readonly fresh?: true;
	/**
	 * Check if the request is stale, aka
	 * "Last-Modified" and / or the "ETag" for the
	 * resource has changed.
	 *
	 * Does not make sense in a pure browser context so returns false by default
	 *
	 * @return {boolean} false
	 */
	readonly stale?: false;
	/**
	 * Check if the request was an _XMLHttpRequest_.
	 *
	 * @return {boolean} true if the request was an _XMLHttpRequest_
	 */
	readonly xhr?: boolean;
	/**
	 * Get the URL associated with the request
	 *
	 * @return {string} the url associated with the request
	 */
	readonly url?: string;
	/**
	 * Get HTTP request method
	 *
	 * @return {string} a string of the HTTP request method
	 */
	readonly method?:
		| "GET"
		| "HEAD"
		| "POST"
		| "PUT"
		| "DELETE"
		| "CONNECT"
		| "OPTIONS"
		| "TRACE"
		| "PATCH";
	/**
	 * Does not make sense in a pure browser context so returns an empty object
	 *
	 * @return {Object} an object
	 */
	readonly trailers?: Record<string, string>;
	/**
	 * Does not make sense in a pure browser context so returns -1
	 *
	 * @return {number} a number
	 */
	readonly statusCode?: number;
	/**
	 * Does not make sense in a pure browser context so returns an empty string
	 *
	 * @return {string} a string
	 */
	readonly statusMessage?: string;
	/**
	 * Does not make sense in a pure browser context so returns an empty string
	 *
	 * @return {string} a string
	 */
	readonly httpVersion?: string;
	/**
	 * Does not make sense in a pure browser context so returns an empty string by default
	 *
	 * @return {string} an empty string
	 */
	readonly ip?: string;
	/**
	 * Does not make sense in a pure browser context so returns an empty string array by default
	 *
	 * @return {string} an empty string array
	 */
	readonly ips?: string[];
	/**
	 * Does not make sense in a pure browser context so returns an empty array by default
	 *
	 * @return {string[]} an empty string array
	 */
	readonly subdomains?: string[];
}
