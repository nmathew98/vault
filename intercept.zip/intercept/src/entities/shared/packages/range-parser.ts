/**
 * Interface for the `Range` header parser
 *
 * Based on `range-parser`
 */
export interface RangeParser {
	/**
	 * Parse the `Range` header and return an array of ranges or negative numbers
	 * if parsing has failed
	 *
	 * @param {number} size the maximum size of the resource
	 * @param {string} header the value of the `Range` header
	 * @param {Object} options to pass to the parser
	 * @returns {Object[] | number} an array of ranges or negative numbers if parsing has failed
	 */
	parse: (
		size: number,
		range: string,
		options?: { combine: boolean },
	) => { start: number; end: number; index?: number }[] | number;
}
