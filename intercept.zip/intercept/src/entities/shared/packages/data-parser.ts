export interface StringyDataParser {
	stringify: (data: any) => string;
	parse: (data: string) => any;
}

export type StringyData = {
	toString: () => string;
};

export type BinaryData = {
	toString: (encoding?: BinaryEncoding, start?: number, end?: number) => string;
	buffer: ArrayBuffer;
	length: number;
};

export type BinaryEncoding =
	| "ascii"
	| "utf8"
	| "utf-8"
	| "utf16le"
	| "ucs2"
	| "ucs-2"
	| "base64"
	| "base64url"
	| "latin1"
	| "binary"
	| "hex";
