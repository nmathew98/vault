export interface Charset {
	get: (type: string, encoding: string) => string;
	lookup: (type: string) => string | undefined;
}
