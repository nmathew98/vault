/**
 * Interface for the `Accept` header parser
 *
 * Based on `@hapi/accept`
 */
export interface AcceptParser {
	/**
	 * Get the best fit media type that should be used in the HTTP response
	 * given a string of media types
	 *
	 * @param {string} types media types from the `Accept` header
	 * @param {string[]} preferences the preferred media types
	 * @returns {string} the best match media type or void if there is none
	 */
	type: (types: string, preferences: string[]) => string | void;
	/**
	 * Get the best fit charset that should be used in the HTTP response
	 * given a string of charsets
	 *
	 * @param {string} types charsets from the `Accept-Charset` header
	 * @param {string[]} preferences the preferred charsets
	 * @returns {string} the best charset or void if there is none
	 */
	charset: (charsets: string, preferences: string[]) => string | void;
	/**
	 * Get the best fit encoding that should be used in the HTTP response
	 * given a string of encodings
	 *
	 * @param {string} types encoding from the `Accept-Encoding` header
	 * @param {string[]} preferences the preferred encodings
	 * @returns {string} the best match encoding or void if there is none
	 */
	encoding: (encodings: string, preferences: string[]) => string | void;
	/**
	 * Get the best fit language that should be used in the HTTP response
	 * given a string of languages
	 *
	 * @param {string} types language ranges from the `Accept-Language` header
	 * @param {string[]} preferences the preferred languages
	 * @returns {string} the best match language or void if there is none
	 */
	language: (languages: string, preferences: string[]) => string | void;
}
