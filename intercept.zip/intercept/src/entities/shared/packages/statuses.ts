export interface Statuses {
	status: (code: number) => string;
}
