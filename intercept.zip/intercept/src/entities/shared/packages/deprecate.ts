/**
 * Interface for the `Deprecate` package
 *
 * Based on `deprecate`
 */
export interface Deprecate {
	/**
	 * Print a message to the output stream the first time the
	 * deprecated function is called
	 *
	 * @param {string} message the message to print
	 * @returns {void}
	 */
	deprecate: (message: string) => void;
}
