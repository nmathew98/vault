/**
 * Interface for the `URLParser` package
 *
 * Based on `ufo`
 */
export interface URLParser {
	/**
	 * Check if a given path matches a url
	 *
	 * @param {string} path the path
	 * @param {string} url the url
	 * @returns {boolean} true if the path matches the url
	 */
	match: (path: string, url: string) => boolean;
	/**
	 * Parse a URL and extract information contained within
	 *
	 * @param {string} url The url
	 * @returns {Object} a ParsedURL
	 */
	parse: (url: string) => Partial<ParsedURL>;
}

/**
 * A parsed url
 */
export type ParsedURL = {
	/**
	 * The hash part of a URL
	 *
	 * @type {string}
	 */
	hash: string;
	/**
	 * The hostname associated with the URL
	 *
	 * @type {string}
	 */
	hostname: string;
	/**
	 * The pathname associated with the URL
	 *
	 * @type {string}
	 */
	pathname: string;
	/**
	 * The port associated with the URL
	 *
	 * @type {string}
	 */
	port: string;
	/**
	 * The protocol associated with the URL
	 *
	 * @type {string}
	 */
	protocol: string;
	/**
	 * An object with the URL query parameter as the key and
	 * the value of the query parameter as the value of the key
	 *
	 * @type {Object}
	 */
	query: Record<string, any>;
};
