interface Utils {
	defineGetter: (
		object: Record<string, any>,
		name: string,
		getter: (...args: any[]) => any,
	) => void;
	isVoid: (x: any) => x is void;
}

const Utils: Utils = {
	defineGetter: (
		object: Record<string, any>,
		name: string,
		getter: (...args: any[]) => any,
	) => {
		if (!(name in object))
			Object.defineProperty(object, name, {
				configurable: true,
				enumerable: true,
				get: getter,
			});
	},
	isVoid: (x: any): x is void => {
		return x === undefined || x === null;
	},
};

export default Utils;
