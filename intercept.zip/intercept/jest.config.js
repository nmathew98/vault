/** @type {import('ts-jest/dist/types').InitialOptionsTsJest} */
module.exports = {
	preset: "ts-jest",
	globals: {
		"ts-jest": {
			tsconfig: "tsconfig.spec.json",
			useESM: true,
		},
	},
	testEnvironment: "node",
	moduleDirectories: ["node_modules"],
};
