![Tests](https://github.com/nmathew98/intercept/actions/workflows/main.yml/badge.svg)

# About

A client side "server" and a collection of middleware to be used in service workers.

It's compatible with express style middleware.
