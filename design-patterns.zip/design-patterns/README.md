Implement these design patterns
Creational:
- Abstract Factory
- Builder
- Factory Method
- Prototype
- Singleton

Structural:
- Adapter
- Bridge
- Composite
- Decorator
- Facade
- Flyweight
- Proxy

Behavioural:
- Chain of Responsibility
- Command
- Interpreter
- Iterator
- Mediator
- Memento
- Observer
- State
- Strategy
- Template Method
- Visitor

Foundations:
- List
- Iterator
- ListIterator
- Point
- Rect