/**
 * Intent: Provide a unified interface to a set of interfaces in a subsystem.
 * Facade defines a higher-level interface that makes the subsystem easier to use.
 * 
 * Example: One entry point which then triggers a whole host of other operations.
 */

class EmployeeFacade {
    private __name: string;
    private __bank: Bank;
    private __accountingSystem: AccountingSystem;
    private __payroll: Payroll;

    constructor(name: string, bank: Bank, accountingSystem: AccountingSystem, payroll: Payroll) {
        this.__name = name;
        this.__bank = bank;
        this.__accountingSystem = accountingSystem;
        this.__payroll = payroll;
    }

    public pay(money: number) {
        this.__accountingSystem.addEntry(this.__name, money);
        this.__payroll.addEntry(this.__name, money);
        this.__bank.debit(this.__name, money);

        console.log(`Paid ${this.__name}`);
    }
}

class Bank {
    public debit(name: string, money: number) {
        console.log(`[Bank] Deposited ${money.toFixed(2)} to ${name}`);
    }
}

class AccountingSystem {
    public addEntry(name: string, money: number) {
        console.log(`[Accounting] Added entry for ${name} worth ${money.toFixed(2)}`);
    }
}

class Payroll {
    public addEntry(name: string, money: number) {
        console.log(`[Payroll] Added income for ${name}, value: ${money.toFixed(2)}`);
    }
}

const employee = new EmployeeFacade("Test", new Bank(), new AccountingSystem(), new Payroll());
employee.pay(15);