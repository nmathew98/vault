/**
 * Intent: Compose objects into tree structures to represent part-whole hierarchies.
 * Composite lets clients treat individual objects and compositions of objects uniformly.
 * 
 * Example: Kind of like recursion. From GoF, a picture is made up of many graphics
 * (which is made up of many primitives), so you treat them the same by making them conform to the
 * same interface (picture and graphics). The behaviour of `Graphic` and `Picture` does not differ, unlike in
 * decorator.
 */

abstract class Vector {
    public abstract draw(): void;
}

class Graphic extends Vector {
    private __id: string;

    constructor(id: string) {
        super();
        this.__id = id;
    }

    public draw() {
        console.log(`Drew graphic ${this.__id}`);
    }
}

class Picture extends Vector {
    private __id: string;
    private __graphics: Vector[];

    constructor(id: string, graphics: Vector[]) {
        super();
        this.__id = id;
        this.__graphics = graphics;
    }

    public draw() {
        this.__graphics.forEach(graphic => graphic.draw());
        
        console.log(`Drew picture ${this.__id}`);
    }
}

const graphics = new Array(10).fill(null).map(() => new Graphic(`${Date.now()}`));
const picture = new Picture(`${Date.now()}`, graphics);

picture.draw()