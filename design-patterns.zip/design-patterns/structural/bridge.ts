/**
 * Intent: Decouple an abstraction from its implementation so that the two can vary
 * independently.
 *
 * Example: We have an abstraction and a concretion which does not conform to the abstraction,
 * we join the two together with a bridge, translating one representation to another.
 */

class AbstractGroceryStore {
  private __store: ConcreteGroceryStore;

  constructor(store: ConcreteGroceryStore) {
    this.__store = store;
  }

  public showItems() {
    const list = this.__store.aggregateItems();

    console.log(JSON.stringify(list, null, 2));
  }
}

class ConcreteGroceryStore {
  private __name: string;
  private __items: string[];

  constructor(name: string, items: string[]) {
    this.__name = name;
    this.__items = items;
  }

  public aggregateItems() {
    const counts = this.__items.reduce(
      (counts, item) => ({
        ...counts,
        [item]: (counts?.[item] ?? 0) + 1,
      }),
      Object.create(null)
    );

    return {
      store: this.__name,
      ...counts,
    };
  }
}

const countdown = new AbstractGroceryStore(
  new ConcreteGroceryStore("Countdown", ["chicken", "chicken", "fish"])
);

countdown.showItems()
