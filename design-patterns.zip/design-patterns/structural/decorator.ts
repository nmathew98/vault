/**
 * Intent: Attach additional responsibilities to an object dynamically. Decorators provide
 * a flexible alternative to subclassing for extending functionality.
 * 
 * Example: Wrapping a class with another class. Both classes must conform to the same interface.
 * From GoF, you can have a `ViewElement` and a `View` is just many `ViewElements`, so you can wrap these things
 * and then call draw on one to draw everything one at a time. The behaviour of `View` and `ViewElement` differs, unlike
 * in composite.
 */

abstract class View {
    protected static count: number = 1;
    public abstract draw(): void;
}

class ScrollView extends View {
    private __wraps?: View;

    constructor(view?: View) {
        super();
        this.__wraps = view;
    }

    public draw() {
        this.__wraps?.draw();
        console.log(`Drew scrollbar ${View.count++}`);
    }
}

class TextView extends View {
    private __wraps?: View;

    constructor(view?: View) {
        super();
        this.__wraps = view;
    }

    public draw() {
        this.__wraps?.draw();
        console.log(`Drew text view ${View.count++}`);
    }
}

const scrollableTextView = new ScrollView(new TextView(new ScrollView(new TextView())));

scrollableTextView.draw()