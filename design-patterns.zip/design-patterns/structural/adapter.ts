/**
 * Intent: Convert the interface of a class into another interface clients expect.
 * Adapter lets classes work together that couldn't otherwise because of incompatible
 * interfaces
 *
 * Example: When integrating libraries, if you have many choices libraries that provide the same functionality,
 * you can provide a standard interface for all of them, there is no translation layer here unlike in the bridge pattern.
 */

interface Greeter {
	greet: () => void;
}

class Target implements Greeter {
	private __greeter: Greeter;

	constructor(greeter: Greeter) {
		this.__greeter = greeter;
	}

	greet() {
		this.__greeter.greet();
	}
}

class PersonAdapter implements Greeter {
	private __person: Person;

	constructor(person: Person) {
		this.__person = person;
	}

	public greet() {
		this.__person.greet("en-us");
	}
}

class ComputerAdapter {
	private __computer: Computer;

	constructor(computer: Computer) {
		this.__computer = computer;
	}

	public greet() {
		this.__computer.greet("Windows");
	}
}

class Person {
	private __name: string;

	constructor(name: string) {
		this.__name = name;
	}

	public greet(language: string) {
		console.log(
			`Hi my name is ${this.__name} and I speak ${language} (specifically)`
		);
	}
}

class Computer {
	public greet(os: string) {
		console.log(`A new ${os} update is available, please restart`);
	}
}

const personGreeter = new Target(new PersonAdapter(new Person("")));
const computerGreeter = new Target(new ComputerAdapter(new Computer()));

personGreeter.greet();
computerGreeter.greet();
