/**
 * Intent: Use sharing to support large numbers of fine-grained objects efficiently.
 * 
 * Example: This is like memoization for classes, instead of creating new instances of classes for representations
 * that already exists, you just reuse the existing representation. You split metadata (extrinstic state) and
 * what makes the object unique (instrinsic state) and reuse the unique (more expensive) stuff.
 * Make the more expensive stuff intrinsic and the less expensive stuff extrinsic.
 */

class Point {
    private __degree: number;

    constructor(degree: number) {
        this.__degree = degree;
    }

    public get degree() {
        return this.__degree;
    }
}

class FlyweightPoint {
    private __points: Map<number, Point> = new Map();
    private __counts: number[] = [];

    constructor() {
        for (let i = 0; i <= 360*10; i++) {
            const mod = i % 360;

            if (this.__points.has(mod)) {
                this.__counts.push(mod);
            } else {
                const point = new Point(mod);

                this.__points.set(mod, point);
                this.__counts.push(mod);
            }
        }
    }

    public draw() {
        const mapped = this.__counts.map((mod, i) => ({ 
            point: i,
            degree: this.__points.get(mod)?.degree 
        }));

        console.log(mapped);
        console.log(`Actual number of points ${this.__points.size}`)
    }
}

const flyweight = new FlyweightPoint();
flyweight.draw();
