/**
 * Intent: Provide a surrogate or placeholder for another object to control access to it.
 * 
 * Example: You have a `File` and a `LazyFile`. When `File` is instantiated, operations are performed
 * immediately. When `LazyFile` is instantiated, operations are deferred until a method is actually called.
 * You are intercepting a method call which allows you to perform operations before and after or
 * stub it out entirely. Similar to the decorator pattern but its more focused on performing more operations
 * under the same responsibility, whereas with decorator you are adding responsibilities.
 */

type Constructor<T= any> = { new (...args: any[]): T; };

abstract class Filesystem {
    public abstract open(file: string): void;
}

class BrokenFilesystem extends Filesystem {
    constructor() {
        super();

        while (true)
            console.log("You should not have done that!!!");
    }

    public open(file: string) {
        console.log(`Opened file: ${file}!`);
    }
}

class LazyFile extends Filesystem {
    private __filesystemConstructor: Constructor<Filesystem>;
    private __instance?: Filesystem;

    constructor(constructor: Constructor<Filesystem>) {
        super();
        this.__filesystemConstructor = constructor;
    }

    public open(file: string) {
        if (!this.__instance)
            this.__instance = new this.__filesystemConstructor();

        this.__instance.open(file);
    }
}

const file = new LazyFile(BrokenFilesystem).open("hello")
