/**
 * Intent: Without violating encapsulation, capture and externalize an object's internal state so
 * that the object can be restored to this state later.
 *
 * Example: Each time the internal state of an object changes, we store it in a memento,
 * its basically an append only log so you can restore an object to a previous state. We could
 * also just keep 1.
 */

abstract class Command {
	public abstract get key(): Symbol;
	public abstract execute(...parameters: any[]): void;
	public abstract undo(): any;
}

abstract class Memento<T> {
	protected abstract states: T[];

	public abstract get where(): number;
	public abstract setState(state: T): void;
	public abstract getState(n: number): T;
}

class Menu implements Omit<Command, "key"> {
	private memento: MenuMemento = new MenuMemento();
	private __commands = new Map();

	constructor(...commands: Command[]) {
		commands.forEach((command) => {
			this.__commands.set(command.key, command);
		});
	}

	public execute(key: Symbol) {
		if (this.__commands.has(key)) {
			const command = this.__commands.get(key);

			command.execute();

			this.memento.setState({ executed: key });
		}

		return this;
	}

	public undo(): Menu {
		if (!~this.memento.where)
			console.log("No more!!!", this.memento.where)

		const previousState = this.memento.getState(this.memento.where - 1);

		if (previousState) {
			const previousExecuted = this.__commands.get(previousState.executed);

			previousExecuted.undo();
		}

		return this;
	}
}

class MenuMemento extends Memento<{ executed: Symbol }> {
	private __currentPosition: number = -1;
	protected states: { executed: Symbol }[] = [];

	public get where() {
		return Math.max(this.__currentPosition, -1);
	}

	public get length() {
		return this.states.length;
	}

	public setState(state: { executed: Symbol }): void {
		this.states.push(state);
		this.__currentPosition = this.states.length;
	}

	public getState(position: number) {
		this.__currentPosition = position;

		return this.states[position] ?? null;
	}
}

class NewCommand extends Command {
	public static key = Symbol("new");

	public get key() {
		return NewCommand.key;
	}

	public execute(): void {
		console.log("Clicked Add!");
	}

	public undo(): void {
		console.log("Undone Add!");
	}
}

class SaveCommand extends Command {
	public static key = Symbol("save");

	public get key() {
		return SaveCommand.key;
	}

	public execute(): void {
		console.log("Clicked Save!");
	}

	public undo(): void {
		console.log("Undone Save!");
	}
}

class DeleteCommand extends Command {
	public static key = Symbol("delete");

	public get key() {
		return DeleteCommand.key;
	}

	public execute(): void {
		console.log("Clicked Delete!");
	}

	public undo(): void {
		console.log("Undone Delete!");
	}
}

const menu = new Menu(new NewCommand(), new SaveCommand(), new DeleteCommand());
menu
	.execute(NewCommand.key)
	.execute(SaveCommand.key)
	.execute(DeleteCommand.key)
	.undo()
	.undo()
	.undo()
	.undo();
