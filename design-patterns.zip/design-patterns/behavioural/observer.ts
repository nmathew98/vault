/**
 * Intent: Define a one-to-many dependency between objects so that when one object changes state,
 * all its dependents are notified and updated automatically.
 * 
 * Exaples: Observables, React.
 */

abstract class Subscriber {
    public abstract handle(value: any): void;
}

class Observable {
    private __subscribers: Subscriber[];

    constructor() {
        this.__subscribers = [];
    }

    push(value: any) {
        this.__subscribers.forEach(subscriber => subscriber.handle(value));
    }

    subscribe(subscriber: Subscriber) {
        this.__subscribers.push(subscriber);

        return this;
    }
}

class UserA extends Subscriber {
    public handle(value): void {
        console.log(`Received "${value}" from A`);
    }
}

class UserB extends Subscriber {
    public handle(value: any): void {
        console.log(`Received "${value}" from B`);
    }
}

const observable = new Observable();
const userA = new UserA();
const userB = new UserB();

observable.subscribe(userA).subscribe(userB);

observable.push('hello world')