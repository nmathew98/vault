/**
 * Intent: Define a family of algorithms, encapsulate each one, and make them interchangeable. Strategy
 * lets the algorithm vary independently from clients that use it.
 * 
 * Example: Many (mostly useless) ways to go through a sequence, we can implement strategies
 * for the different ways of going about it and also graph traversals.
 */

interface Iterator<T> {
	[Symbol.iterator]: () => {
		next: () => {
			value: any;
			done: boolean;
		};
	};
}

abstract class IterationStrategy<T> implements Iterator<T> {
	public abstract [Symbol.iterator](): {
		next: () => { value: any; done: boolean };
	};
}

class Collection<T> implements Iterator<T> {
	private __collection: T[];

	constructor(values: T[]) {
		this.__collection = values;
	}

	public map(
		callback: (
			currentValue: any,
			currentIndex: number,
			collection: T[]
		) => typeof currentValue
	) {
		const iterator = this[Symbol.iterator]();
		const newCollection: T[] = [];

		for (
			let currentValue = iterator.next(), i = 0;
			!currentValue.done;
			currentValue = iterator.next(), i++
		) {
			const newValue = callback(currentValue.value, i, this.__collection);

			newCollection.push(newValue);
		}

		return new Collection(newCollection);
	}

	public forEach(
		callback: (
			currentValue: any,
			currentIndex: number,
			collection: T[]
		) => typeof currentValue
	) {
		const iterator = this[Symbol.iterator]();

		for (
			let currentValue = iterator.next(), i = 0;
			!currentValue.done;
			currentValue = iterator.next(), i++
		) {
			callback(currentValue.value, i, this.__collection);
		}

		return this;
	}

	public setStrategy(iterator: IterationStrategy<T>) {
		this[Symbol.iterator] = iterator[Symbol.iterator].bind(this);

		return this;
	}

	private [Symbol.iterator]() {
		let currentIndex = 0;

		return {
			next: () => {
				const nextValue = {
					value: this.__collection[currentIndex],
					done: !(currentIndex < this.__collection.length),
				};

				if (currentIndex < this.__collection.length) currentIndex++;

				return nextValue;
			},
		};
	}
}

class ReverseIterator<T> extends IterationStrategy<T> {
	public [Symbol.iterator]() {
		console.log("Reverse iterating!");

		let currentIndex = this.__collection.length - 1;

		return {
			next: () => {
				const nextValue = {
					value: this.__collection[currentIndex],
					done: currentIndex < 0,
				};

				if (currentIndex >= 0) currentIndex--;

				return nextValue;
			},
		};
	}
}

const x = new Collection([1, 2, 3, 4])
	.map((currentValue, currentIndex) => {
		return currentValue + 1;
	})
	.forEach((currentValue) => console.log(currentValue))
	.setStrategy(new ReverseIterator())
	.forEach((currentValue) => console.log(currentValue));
