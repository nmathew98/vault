/**
 * Intent: Provide a way to access the elements of an aggregate object sequentially without exposing its
 * underlying representation.
 *
 * Example: `map`, `forEach`, et cetera. Doing this lifts the constraint of even having a collection of
 * elements to begin with, we can have a function that lazy evaluates results and iterate upon this results.
 */

interface Iterator<T> {
	[Symbol.iterator]: () => {
		next: () => {
			value: any;
			done: boolean;
		};
	};
}

class Collection<T> implements Iterator<T> {
	private __collection: T[];

	constructor(values: T[]) {
		this.__collection = values;
	}

	public map(
		callback: (
			currentValue: any,
			currentIndex: number,
			collection: T[]
		) => typeof currentValue
	) {
		const iterator = this[Symbol.iterator]();
		const newCollection: T[] = [];

		for (
			let currentValue = iterator.next(), i = 0;
			!currentValue.done;
			currentValue = iterator.next(), i++
		) {
			const newValue = callback(
				currentValue.value,
				i,
				this.__collection
			);

			newCollection.push(newValue);
		}

		return new Collection(newCollection);
	}

	public forEach(callback: (
		currentValue: any,
		currentIndex: number,
		collection: T[]
	) => typeof currentValue) {
		const iterator = this[Symbol.iterator]();

		for (
			let currentValue = iterator.next(), i = 0;
			!currentValue.done;
			currentValue = iterator.next(), i++
		) {
			callback(
				currentValue.value,
				i,
				this.__collection
			);
		}
	}

	protected [Symbol.iterator]() {
		let currentIndex = 0;

		return {
			next: () => {
				const nextValue = {
					value: this.__collection[currentIndex],
					done: !(currentIndex < this.__collection.length)
				}

				if (currentIndex < this.__collection.length)
					currentIndex++;

				return nextValue;
			},
		};
	}
}

const x = new Collection([1, 2, 3, 4]).map((currentValue, currentIndex) => {
	return currentValue + 1;
}).forEach((currentValue) => console.log(currentValue))
