/**
 * Intent: Define an object that encapsulates how objects interact. Mediator promotes loose coupling
 * by keeping objects from referring to each other explicitly, and it lets you vary their interaction
 * independently.
 * 
 * Example: Mediators sit between objects, so if an event is triggered from one object, mediator
 * takes care of what happens to the other objects. It is the coordinator.
 */