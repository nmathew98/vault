/**
 * Intent: Allow an object to alter its behaviour when its internal state changes. The object will
 * appear to change its class.
 *
 * Examples: From GoF, changing the class of the `TCPState` depending on the connection status.
 */

abstract class TCPStates {
	public abstract get key(): string | null;

	public abstract open(): void;
	public abstract close(): void;
	public abstract acknowledge(): void;
}

class TCPState extends TCPStates {
	public state: TCPStates | null = null;

	public get key() {
		return this.state ? this.state.key : null;
	}

	public open() {
		this.state = new TCPEstablished();

		return this;
	}

	public close() {
		this.state = new TCPClosed();

		return this;
	}

	public acknowledge() {
		this.state = new TCPListen();

		return this;
	}
}

class TCPEstablished extends TCPStates {
	public key = "TCPEstablished";

	public open() {
		return this;
	}

	public close() {
		return this;
	}

	public acknowledge() {
		return this;
	}
}

class TCPClosed extends TCPStates {
	public key = "TCPClosed";

	public open() {
		return this;
	}

	public close() {
		return this;
	}

	public acknowledge() {
		return this;
	}
}

class TCPListen extends TCPStates {
	public key = "TCPListen";

	public open() {
		return this;
	}

	public close() {
		return this;
	}

	public acknowledge() {
		return this;
	}
}

const tcpState = new TCPState().open().close();

console.log(tcpState.key)