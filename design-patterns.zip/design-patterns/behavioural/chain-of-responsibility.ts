/**
 * Intent: Avoid coupling the sender of a request to its receiver by giving more than one object a chance
 * to handle the request. Chain the receiving objects and pass the request along the chain until an object
 * handles it.
 * 
 * Examples: Node middleware work like this, we pass requests along the chain until one of them sets
 * the `writableEnded` flag at which point the request will no longer be processed.
 */

abstract class StackItem {
    public abstract execute(request: Record<string, any>): any;
}

class Stack implements StackItem {
    private __request: Record<string, any>
    private __stack: StackItem[] = [];

    constructor(request: Record<string, any>) {
        this.__request = request;
    }

    public push(...items: StackItem[]): Stack {
        this.__stack.push(...items);

        return this;
    }

    public execute() {
        return this.__stack.reduce((req, item) => {
            if (!req.writableEnded)
                return item.execute(req)

            return req
        }, this.__request);
    }
}

class Logger extends StackItem {
    public execute(request: Record<string, any>) {
        console.log("Hello world!!");

        return request;
    }
}

class ParseBody extends StackItem {
    public execute(request: Record<string, any>): void {
        console.log("Executed ParseBody");

        return JSON.parse(request.body);
    }
}

class Send extends StackItem {
    public execute(request: Record<string, any>): any {
        console.log("Executed Send");

        return {
            ...request,
            writableEnded: true
        }
    }
}

class AddHeader extends StackItem {
    public execute(request: Record<string, any>) {
        console.log("Executed AddHeader");

        return {
            ...request,
            headers: {
                ...request?.headers,
                'Hello': 'World'
            }
        }
    }
}

const request = {
    body: JSON.stringify(Object.create(null)),
};
const stack = new Stack(request).push(new ParseBody(), new Logger()).push(new Send()).push(new AddHeader());
