/**
 * Intent: Encapsulate a request as an object, thereby letting you parameterize clients with different requests,
 * queue or log requests, and support undoable opeations.
 * 
 * Examples: From GoF, each menu item is a `Command` and whenever one is clicked we call `execute`, and to undo
 * we call `revert`. Use in conjuction with memento to implement `revert`.
 */

abstract class Command {
    public abstract get key(): Symbol;
    public abstract execute(...parameters: any[]): void;
}

class Menu implements Omit<Command, 'key'> {
    private __commands = new Map()
    
    constructor(...commands: Command[]) {
        commands.forEach(command => {
            this.__commands.set(command.key, command.execute)
        })
    }

    public execute(command: Symbol) {
        if (this.__commands.has(command)) {
            const f = this.__commands.get(command);

            f();
        }

        return this;
    }
}

class NewCommand extends Command {
    public static key = Symbol('new');

    public get key() {
        return NewCommand.key;
    }

    public execute(): void {
        console.log('Clicked Add!');
    }
}

class SaveCommand extends Command {
    public static key = Symbol('save');

    public get key() {
        return SaveCommand.key;
    }

    public execute(): void {
        console.log('Clicked Save!');
    }
}

class UndoCommand extends Command {
    public static key = Symbol('undo');

    public get key() {
        return UndoCommand.key;
    }

    public execute(): void {
        console.log('Clicked Undo!');
    }
}

class DeleteCommand extends Command {
    public static key = Symbol('delete');

    public get key() {
        return DeleteCommand.key;
    }

    public execute(): void {
        console.log('Clicked Delete!');
    }
}

const menu = new Menu(new NewCommand(), new SaveCommand(), new UndoCommand(), new DeleteCommand());
menu.execute(NewCommand.key).execute(SaveCommand.key);