/**
 * Intent: Represent an operation to be performed on the elements of an object structure.
 * Visitor lets you define a new operation without changing the classes of the elements on which it operates.
 * 
 * Examples: In a graph if we have many different types of nodes and we want to treat them the same when
 * we visit them.
 */