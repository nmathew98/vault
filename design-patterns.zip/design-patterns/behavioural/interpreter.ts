/**
 * Intent: Given a language, define a representation for its grammar along with an interpreter
 * that uses the representation to interpret sentences in the language.
 * 
 * Example: We can implement regex using the interpreter pattern.
 */