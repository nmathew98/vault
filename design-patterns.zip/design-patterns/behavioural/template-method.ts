/**
 * Intent: Define the skeleton of an algorithm in an operation, deferring some steps to subclasses.
 * Template Method lets subclasses redefine certain steps of an algorithm without changing the algorithm's
 * structure.
 * 
 * Example: Kind of like dependency injection for strategy. We can have an abstract class which defines
 * an algorithm along with abstract methods of operations and then subclasses have to specify how those are
 * handled.
 */