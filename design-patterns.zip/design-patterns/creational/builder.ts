/**
 * Intent: Separate the construction of a complex object from its representations 
 * so that the same construction process can create different representations
 * 
 * In summary: this means the shape of every object created stays the same.
 * Classes are an example of an application of the builder pattern.
 */

interface Home {
    roof: string;
    walls: string;
    decoration: string;
}

class GenericHome {
    private roof: string | null;
    private walls: string | null;
    private decoration: string | null;

    constructor() {
        this.__blank();
    }

    public setRoof(roof: string): GenericHome {
        this.roof = roof;
        
        return this;
    }

    public setWalls(walls: string): GenericHome {
        this.walls = walls;

        return this;
    }

    public setDecoration(decoration: string): GenericHome {
        this.decoration = decoration;

        return this;
    }

    public assemble(): Home {
        if (!this.roof || !this.walls || !this.decoration)
            throw new Error("Invalid configuration");

        const home = {
            roof: this.roof,
            walls: this.walls,
            decoration: this.decoration
        }

        this.__blank();

        return home;
    }

    private __blank() {
        this.roof = null;
        this.walls = null;
        this.decoration = null;
    }
}