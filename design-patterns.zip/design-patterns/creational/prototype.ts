/**
 * Intent: Specify the kinds of objects to create using a prototypical instance, and create new 
 * objects by copying the prototype.
 * 
 * In summary: All children of an object have a reference to its parents prototype. This is an
 * alternative to subclassing, JavaScript has prototypical inheritance.
 */

class Prototype {
	private __parent?: Prototype;
	private __prototype?: Record<string, any>;

	constructor(parent?: Prototype) {
		this.__parent = parent;
	}

	public clone() {
		const cloned = new Prototype(this);

		return cloned;
	}

	get prototype() {
		if (this.__prototype)
			return this.__prototype
		else
			return this.__parent?.__prototype;
	}

	set prototype(values) {
		this.__prototype = {
			...this?.__prototype,
			...values
		}
	}
}

const a = new Prototype();
a.prototype = {
	hello: 'world'
}

console.log(a.prototype);

const b = a.clone();
console.log(b.prototype)