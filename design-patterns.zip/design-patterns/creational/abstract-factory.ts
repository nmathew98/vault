/**
 * Intent: Provide an interface for creating families of related or dependent objects without
 * specifying their concrete classes.
 * 
 * In summary: No different to specifying an interface for a class to adhere to with the exception
 * that using an abstract factory allows you to specify implementations. Middle ground between
 * abstract and concrete.
 */

abstract class Polygon {
    public abstract get sides(): number;

    public get color() {
        return "blue";
    }
}

class Square extends Polygon {
    public get sides() {
        return 4;
    }

    public get color() {
        return "red";
    }
}

class Pentagon extends Polygon {
    public get sides() {
        return 5;
    }
}

class NearlyCircle extends Polygon {
    public get sides() {
        return 9999999;
    }
}