/**
 * Intent: Ensure a class only has one instance, and provide a global point of access to it.
 * 
 * In summary: There can only be one
 */
class Singleton {
    private __date: number = -1;
	private static __instance: Singleton | null = null;

    private constructor() {
        this.__date = Date.now();
    }

	static create() {
		if (!this.__instance) {
			this.__instance = new Singleton();
		}

		return this.__instance;
	}

    get which() {
        return Singleton.__instance?.__date;
    }
}