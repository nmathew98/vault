/**
 * Intent: Define an interface for creating an object, but let subclasses decide which class
 * to instantiate. Factory Method lets a class defer instantiation to subclasses.
 * 
 * In summary: the construction of an object is split from its implementation,
 * the constructor adheres to its own interface and its implementation can vary but still produce
 * the same (structurally) object
 */
abstract class Restaurant {
	public abstract cook(size: "small" | "medium" | "large"): Food;
}

abstract class Food {
	private __size: "small" | "medium" | "large";

	// This is so that every subclass adheres to this interface for the constructor
	constructor(size: "small" | "medium" | "large") {
		this.__size = size
	}

	abstract get price(): number;
	abstract get items(): string[];
}

class FancyRestaurant extends Restaurant {
	public cook(size: "small" | "medium" | "large") {
		return new FancyFood(size)
	}
}

class FancyFood extends Food {
	private __prices = {
		"small": 10,
		"medium": 20,
		"large": 30
	};
	private __price: number;
	private __items: string[];

	constructor(size: "small" | "medium" | "large") {
		super(size);

		this.__price = this.__prices[size];
		this.__items = ['foie gras'];
	}

	get price() {
		return this.__price;
	}

	get items() {
		return this.__items;
	}
}

class NormalRestaurant extends Restaurant {
	public cook(size: "small" | "medium" | "large") {
		return new NormalFood(size);
	}
}

class NormalFood extends Food {
	private __prices = {
		"small": 5,
		"medium": 10,
		"large": 20
	};
	private __price: number;
	private __items: string[];

	constructor(size: "small" | "medium" | "large") {
		super(size);

		this.__price = this.__prices[size];
		this.__items = ['coffee'];
	}

	get price() {
		return this.__price;
	}

	get items() {
		return this.__items;
	}
}

class Dairy extends Restaurant {
	public cook(size: "small" | "medium" | "large") {
		return new DairyFood(size);
	}
}

class DairyFood extends Food {
	private __prices = {
		"small": 20,
		"medium": 30,
		"large": 40
	};
	private __price: number;
	private __items: string[];

	constructor(size: "small" | "medium" | "large") {
		super(size);

		this.__price = this.__prices[size];
		this.__items = [''];
	}

	get price() {
		return this.__price;
	}

	get items() {
		return this.__items;
	}
}

class UmbrellaRestaurant extends Restaurant {
	private __restaurant: Restaurant;

	constructor(creditLimit: number) {
		super();

		if (creditLimit >= 500)
			this.__restaurant = new FancyRestaurant();
		else if (creditLimit >= 200 && creditLimit < 500)
			this.__restaurant = new NormalRestaurant();
		else if (creditLimit >= 100 && creditLimit < 200)
			this.__restaurant = new Dairy();
		else
			this.__restaurant = new Dairy();
	}

	public cook(size: "small" | "medium" | "large") {
		return this.__restaurant.cook(size)
	}
}
