## About

A lightweight GraphQL client which automatically generates queries and mutations, just specify the fields you need selected

## Features

- Automatically generated queries and mutations using introspection queries ✅
- Automatically generated TypeScript type definitions ✅
- In memory caching ✅
- Retry on failure ✅
- Transformers support to process results ✅

## Usage

1. Import the client as part of your server setup and set the client up (example using Express)

```
...
import setupClient from "@skulpture/lynk"

const app = express()

const api = "/api"
const lynkFiles = "./public/lynk"
const configuration = {
	client: {
		base: "http://localhost:3000"
	},
	api: {
		base: "http://localhost:4000"
	}
}

(async () => await setupClient(api, lynkFiles, configuration))()
```

2. Import the client when you do want to use the client in your React/Vue/Svelte file

```
...
import createClient from "@skulpture/lynk"

const api = "/api"
const lynkFiles = "./lynk"
const configuration = {
	client: {
		base: "http://localhost:3000"
	},
	api: {
		base: "http://localhost:4000"
	}
}

const createResolver = createClient(api, lynkFiles, configuration)
const fieldSelection: WhoAmI = {
	uuid: true
}

const whoAmI = createResolver<Pick<WhoAmI, keyof typeof fieldSelection>>({
	resolver: 'whoami', // Required
	selection: fieldSelection, // Required
	affects: [], // Optional, if it is a mutation indicate which queries are affected
	transformers: [], // Optional array of transformers for the result, the result must have the same shape
	dev: false // Optional if you want to see error messages from applying transformers in the browser console
});

const { query, result } = await whoAmI({
	uuid: '123-123-123'
});
```

- The client will retry requests on failure up to 5 times by default, results are automatically cached after the transformers is applied

- For the `affects` field of `createResolver`, the array must contain `jsonToGraphQLQuery` objects, see [jsonToGraphQLQuery](https://github.com/vkolgi/json-to-graphql-query). The query object is returned in the object that is returned when running a resolver.

- The client works by first running an introspection query to fetch the schema from the API and then it stores it in the public directory specified by `lynkFiles`, when running as part of the setup process, `lynkFiles` must point to the public static files directory on the frontend. When running in the browser, `lynkFiles` must point to the path of the lynk files directory (for example, if the schema is stored in `public/lynk/` and Express is set up to serve static files from `public`, then in the browser `lynkFiles` will be `/lynk`)

## Planned functionality

- Automatically generate interfaces for the parameters of a resolver

## Contributions

Contributions are welcome, just make a pull request
