import createLynkClient from "./composables/create-client";

export default createLynkClient;
