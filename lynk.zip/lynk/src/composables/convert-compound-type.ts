import {
	GraphQLEnumType,
	GraphQLObjectType,
	GraphQLScalarType,
	GraphQLSchema,
	GraphQLList,
} from "graphql";
import convertAtomicType from "./convert-atomic-type";

export default function convertCompoundType(
	type: GraphQLObjectType,
	schema: GraphQLSchema,
): Record<string, any> {
	const returnTypes = Object.create(null);
	const fields = type.getFields();

	for (const field in fields) {
		const required = fields[field].type.toString().includes("!");
		const base = schema.getType(fields[field].type.toString().replace("!", ""));

		if (base instanceof GraphQLObjectType)
			returnTypes[field] = {
				...convertCompoundType(base, schema),
				required,
			};

		if (
			base instanceof GraphQLEnumType ||
			base instanceof GraphQLScalarType ||
			base instanceof GraphQLList
		)
			returnTypes[field] = {
				...convertAtomicType(base, schema),
				required,
			};
	}

	return returnTypes;
}
