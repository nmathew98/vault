import { GraphQLSchema } from "graphql";

export default function getMutations(schema: GraphQLSchema) {
	return schema.getMutationType();
}
