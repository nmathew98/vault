import generateInterfaceBody from "./generate-interface-body";

export default function generateDeclaration(
	resolver: string,
	resolverDefinition: Record<string, any>,
) {
	const declarationBody: string[] = [];

	if (!resolverDefinition["value"]) {
		declarationBody.push(`\tinterface ${generateInterfaceName(resolver)} {`);

		const propertyFields = ["required"];
		for (const field in resolverDefinition)
			if (!propertyFields.includes(field))
				declarationBody.push(
					...generateInterfaceBody(field, {
						[field]: resolverDefinition[field],
					}),
				);

		declarationBody.push("\t}");

		const isMutationNonNull = !!resolverDefinition?.isRequired;
		if (isMutationNonNull)
			declarationBody.push(
				`\ttype ${generateTypeName(resolver)} = ${generateInterfaceName(
					resolver,
				)};`,
			);
		else
			declarationBody.push(
				`\ttype ${generateTypeName(resolver)} = ${generateInterfaceName(
					resolver,
				)} | null;`,
			);
	} else {
		const typeName = generateTypeName(resolver);
		const isRequired = !!resolverDefinition?.required;
		const isArray = !!resolverDefinition?.array;
		const typeValue = resolverDefinition.value;

		declarationBody.push(
			`\ttype ${typeName} = ${typeValue}` +
				(isArray ? "[]" : "") +
				(!isRequired ? " | null" : "" + ";"),
		);
	}

	return declarationBody;
}

const generateInterfaceName = (resolver: string) =>
	`${resolver[0].toUpperCase() + resolver.slice(1)}Result`;
const generateTypeName = (resolver: string) =>
	`${resolver[0].toUpperCase() + resolver.slice(1)}`;
