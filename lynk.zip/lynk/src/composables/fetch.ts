import { $fetch } from "ohmyfetch";

export default function makeFetch(partialUrl: string, options: FetchOptions) {
	return async function fetch(query: string, variables?: Record<string, any>) {
		return await $fetch(partialUrl, {
			baseURL: options.base,
			method: "POST",
			body: {
				query,
				variables,
			},
			retry: options?.retry ?? 5,
			headers: options?.headers ?? Object.create(null),
		});
	};
}

export type Fetch = (
	query: string,
	variables?: Record<string, any>,
) => Promise<any>;

export interface FetchOptions {
	base: string;
	retry?: number;
	headers?: Record<string, any>;
}
