import { INTROSPECTION_QUERY } from "../constants/introspection-query";
import createFolder from "./create-folder";
import findRootDirectory from "./find-root-directory";
import { resolve } from "path";
import { writeFile } from "fs/promises";
import { Fetch } from "./fetch";

export default async function fetchSchema(fetch: Fetch, lynkFiles: string) {
	const rootDirectory = await findRootDirectory();
	const schema = await fetch(INTROSPECTION_QUERY);

	const outputDirectory = resolve(rootDirectory, lynkFiles);

	await createFolder(outputDirectory);

	await writeFile(resolve(outputDirectory, "./schema.json"), `${schema}`);
}
