import { GraphQLSchema } from "graphql";
import getMutations from "./get-mutations";
import getQueries from "./get-queries";
import getSubscriptions from "./get-subscriptions";

export default function getResolvers(schema: GraphQLSchema) {
	const queries = getQueries(schema);
	const mutations = getMutations(schema);
	const subscriptions = getSubscriptions(schema);

	return {
		queries: Object.keys(queries ?? Object.create(null)),
		mutations: Object.keys(mutations ?? Object.create(null)),
		subscriptions: Object.keys(subscriptions ?? Object.create(null)),
	};
}
