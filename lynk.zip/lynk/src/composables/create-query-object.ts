import { GraphQLObjectType } from "graphql";
import { VariableType } from "json-to-graphql-query";
import getParameters from "./get-parameters";

export default function createQueryObject<T = FieldSelection>(
	type: "query" | "mutation" | "subscription",
	resolver: string,
	o: GraphQLObjectType,
	selection?: FieldSelection & T,
) {
	const parameters = getParameters(o);

	let __args = Object.create(null);
	if (parameters[resolver])
		__args = Object.keys(parameters[resolver]).reduce(
			(args, parameter) => ({
				...args,
				[parameter]: new VariableType(parameter),
			}),
			Object.create(null),
		);

	return {
		[type]: {
			__variables: parameters[resolver],
			[resolver]: {
				__args,
				...selection,
			},
		},
	};
}

export interface FieldSelection {
	[key: string]: boolean | FieldSelection;
}
