import {
	GraphQLEnumType,
	GraphQLList,
	GraphQLScalarType,
	GraphQLSchema,
} from "graphql";

export default function convertAtomicType(
	type: GraphQLEnumType | GraphQLScalarType | GraphQLList<any>,
	schema: GraphQLSchema,
) {
	const required = type.toString().includes("!");
	const array = type instanceof GraphQLList;
	/*eslint no-useless-escape: "off"*/
	const baseName = type.toString().replaceAll(/[\[\!]]/g, "");
	const base = schema.getType(baseName);
	const types: { [key: string]: string } = {
		String: "string",
		Int: "number",
		Float: "number",
		Boolean: "boolean",
		ID: "number",
	};

	const scalarTypeDetails = (
		type: string,
		required: boolean,
		array: boolean,
	) => ({
		value: type.toLowerCase(),
		required,
		array,
	});
	const enumTypeDetails = (types: string[], required: boolean) => ({
		values: types,
		required,
		array,
	});

	if (base instanceof GraphQLEnumType) {
		return enumTypeDetails(
			base.getValues().map(e => e.name),
			required,
		);
	} else {
		if (!types[baseName]) return scalarTypeDetails("any", required, array);

		return scalarTypeDetails(types[baseName], required, array);
	}
}
