import md5 from "js-md5";
import { jsonToGraphQLQuery } from "json-to-graphql-query";
import localforage from "localforage";
import { Fetch } from "./fetch";

export default function createResolver(configuration: ResolverConfiguration) {
	const key = md5(JSON.stringify(configuration.query));

	return async function resolve<T = Record<string, any>>(
		variables?: Record<string, any>,
	) {
		const query = jsonToGraphQLQuery(configuration.query);

		const fetchResult = async (variables?: Record<string, any>) => {
			const result = await configuration.fetch(query, variables);

			let processed = { ...result };

			if (configuration.transformers)
				for (const transformer of configuration.transformers)
					try {
						processed = await transformer({ ...processed });
					} catch (error: any) {
						if (configuration?.dev)
							/* eslint no-console: "off" */
							console.error(
								`Error while processing result for ${configuration.resolver}: ${error.message} `,
							);
					}

			localforage.setItem(key, JSON.stringify(processed));

			return processed;
		};

		if (configuration.affects) {
			for (const affected of configuration.affects) {
				const key = md5(JSON.stringify(affected));

				await localforage.removeItem(key);
			}
		}

		const resultInStorage = await localforage.getItem(key);

		let result: T = Object.create(null);

		if (resultInStorage) {
			fetchResult(variables);
			result = JSON.parse(resultInStorage as string) as T;
		} else {
			result = (await fetchResult(variables)) as T;
		}

		return {
			query,
			result,
		};
	};
}

interface ResolverConfiguration {
	fetch: Fetch;
	query: Record<string, any>;
	resolver: string;
	dev?: boolean;
	affects?: Record<string, any>[];
	transformers?: Transformers[];
}

export type Transformers = (
	result: Record<string, any>,
) => Promise<Record<string, any>>;
