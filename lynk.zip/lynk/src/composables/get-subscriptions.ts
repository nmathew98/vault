import { GraphQLSchema } from "graphql";

export default function getSubscriptions(schema: GraphQLSchema) {
	return schema.getSubscriptionType();
}
