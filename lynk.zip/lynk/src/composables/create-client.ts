import createResolver, { Transformers } from "./create-resolver";
import makeFetch, { FetchOptions } from "./fetch";
import fetchSchema from "./fetch-schema";
import buildSchema from "./build-schema";
import createQueryObject, { FieldSelection } from "./create-query-object";
import { $fetch } from "ohmyfetch";
import getResolvers from "./get-resolvers";
import getQueries from "./get-queries";
import getMutations from "./get-mutations";
import localforage from "localforage";
import md5 from "js-md5";
import convertCompoundType from "./convert-compound-type";
import generateDeclaration from "./generate-declaration";
import getSubscriptions from "./get-subscriptions";

export default async function createClient(
	api: string,
	lynkFiles: string,
	configuration: LynkConfiguration,
) {
	const fetchApi = makeFetch(api, configuration.api);

	let schema;
	if (process) {
		const { resolve } = await import("path");
		const { default: findRootDirectory } = await import(
			"./find-root-directory"
		);
		const { writeFile } = await import("fs/promises");
		const { default: createFolder } = await import("./create-folder");

		const rootDirectory = await findRootDirectory();

		await fetchSchema(fetchApi, lynkFiles);

		const schemaPath = resolve(
			rootDirectory,
			`./${lynkFiles}`,
			"./schema.json",
		);
		schema = await buildSchema({ path: schemaPath });
		const queries = getQueries(schema);
		const mutations = getMutations(schema);
		const subscriptions = getSubscriptions(schema);

		/**
		 * TODO: Generate TypeScript declarations for arguments based on schema
		 *
		 * This currently generates interfaces for the result of running
		 * a query or mutation
		 */
		{
			await createFolder(resolve(rootDirectory, `./${lynkFiles}`, "./types"));

			const declarationHeader = ["declare global {"];
			const declarationFooter = ["}", "export {};"];
			const queryDeclarations = [];
			const mutationDeclarations = [];
			const subscriptionDeclarations = [];

			if (queries) {
				const queryTypes = convertCompoundType(queries, schema);

				for (const query in queryTypes)
					queryDeclarations.push(
						generateDeclaration(query, queryTypes[query]).join("\n"),
					);
			}

			if (mutations) {
				const mutationTypes = convertCompoundType(mutations, schema);

				for (const mutation in mutationTypes)
					mutationDeclarations.push(
						generateDeclaration(mutation, mutationTypes[mutation]).join("\n"),
					);
			}

			if (subscriptions) {
				const subscriptionTypes = convertCompoundType(subscriptions, schema);

				for (const subscription in subscriptionTypes)
					subscriptionDeclarations.push(
						generateDeclaration(
							subscription,
							subscriptionTypes[subscription],
						).join("\n"),
					);
			}

			if (queryDeclarations.length || mutationDeclarations.length) {
				const declarations = [
					...declarationHeader,
					...queryDeclarations,
					...mutationDeclarations,
					...declarationFooter,
				];

				const declaration = declarations.join("\n");
				const declarationDirectory = resolve(
					rootDirectory,
					`./src/lynk`,
					"./types",
				);

				await createFolder(declarationDirectory);

				const declarationPath = resolve(declarationDirectory, "./global.d.ts");

				await writeFile(declarationPath, declaration);
			}
		}

		{
			const resolvers = getResolvers(schema);

			if (!!queries || !!mutations || !!subscriptions)
				await createFolder(resolve(rootDirectory, `./${lynkFiles}`, "./base"));

			if (queries)
				for (const query in resolvers.queries) {
					const queryObject = createQueryObject("query", query, queries);

					await writeFile(
						resolve(rootDirectory, `./${lynkFiles}`, "./base", `${query}.json`),
						JSON.stringify(queryObject),
					);
				}

			if (mutations)
				for (const mutation in resolvers.mutations) {
					const mutationObject = createQueryObject(
						"mutation",
						mutation,
						mutations,
					);

					await writeFile(
						resolve(
							rootDirectory,
							`./${lynkFiles}`,
							"./base",
							`${mutation}.json`,
						),
						JSON.stringify(mutationObject),
					);
				}

			if (subscriptions)
				for (const subscription in resolvers.subscriptions) {
					const subscriptionObject = createQueryObject(
						"subscription",
						subscription,
						subscriptions,
					);

					await writeFile(
						resolve(
							rootDirectory,
							`./${lynkFiles}`,
							"./base",
							`${subscription}.json`,
						),
						JSON.stringify(subscriptionObject),
					);
				}
		}

		return;
	}

	if (window) {
		schema = await $fetch(`${lynkFiles}/schema.json`, {
			...configuration.client,
			parseResponse: response => buildSchema({ json: JSON.parse(response) }),
		});

		return async <T = Record<string, any>>(
			resolverConfiguration: LynkResolverConfiguration<T>,
		) => {
			const selectionKey = md5(JSON.stringify(resolverConfiguration.selection));
			const finalQueryObjectKey = `${resolverConfiguration.resolver}-${selectionKey}`;

			const finalQueryObjectValueInStorage = await localforage.getItem(
				finalQueryObjectKey,
			);
			let finalQueryObject;

			if (!finalQueryObjectValueInStorage) {
				const baseQueryValueInStorage = await localforage.getItem(
					resolverConfiguration.resolver,
				);

				let baseQueryObject;
				if (!baseQueryValueInStorage) {
					baseQueryObject = await $fetch(
						`${lynkFiles}/base/${resolverConfiguration.resolver}.json`,
						{
							...configuration.client,
						},
					);

					await localforage.setItem(
						resolverConfiguration.resolver,
						JSON.stringify(baseQueryObject),
					);
				} else {
					baseQueryObject = JSON.parse(baseQueryValueInStorage as string);
				}

				const root = Object.keys(baseQueryObject).pop() as string;

				if (!baseQueryObject[root][resolverConfiguration.resolver])
					throw new Error("Invalid base query");

				finalQueryObject = { ...baseQueryObject };
				finalQueryObject[root][resolverConfiguration.resolver] = {
					...finalQueryObject[root][resolverConfiguration.resolver],
					...JSON.parse(
						JSON.stringify(resolverConfiguration.selection, (_, value) => {
							if (typeof value === "object") return value;

							return !!value;
						}),
					),
				};
			} else {
				finalQueryObject = JSON.parse(finalQueryObjectValueInStorage as string);
			}

			return createResolver({
				fetch: fetchApi,
				query: finalQueryObject,
				resolver: resolverConfiguration.resolver,
				dev: resolverConfiguration.dev,
				affects: resolverConfiguration.affects,
				transformers: resolverConfiguration.transformers,
			});
		};
	}

	throw new Error("Unable to detect environment");
}

export interface LynkConfiguration {
	client: FetchOptions;
	api: FetchOptions;
}

export interface LynkResolverConfiguration<T> {
	resolver: string;
	selection: FieldSelection & T;
	affects?: Record<string, any>[];
	transformers?: Transformers[];
	dev?: boolean;
}
