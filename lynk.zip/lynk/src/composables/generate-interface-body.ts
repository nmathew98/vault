export default function generateInterfaceBody(
	resolver: string,
	fields: Record<string, any>,
) {
	const declarationBody: string[] = [];

	for (const field in fields) {
		/**
		 * If the field has a property called `value`, then it is atomic,
		 * if it does not have a property called `value` then it is compound
		 */
		if (!fields[field].value) {
			const queryField = [field];

			const isRequired = !!fields[field]?.required;

			if (isRequired) queryField.push(":");
			else queryField.push("?:");

			queryField.push(...generateInterfaceBody(resolver, fields[field]));

			declarationBody.push(`\t\t${queryField.join(" ")}`);
		} else {
			const queryField = [resolver];

			const isRequired = !!fields[field]?.required;
			const isArray = !!fields[field]?.array;

			if (isRequired) queryField.push(":");
			else queryField.push("?:");

			queryField.push(fields[field].value);

			if (isArray) queryField.push("[]");

			declarationBody.push(`\t\t${queryField.join(" ")}`);
		}
	}

	return declarationBody;
}
