import { GraphQLSchema } from "graphql";

export default function getQueries(schema: GraphQLSchema) {
	return schema.getQueryType();
}
