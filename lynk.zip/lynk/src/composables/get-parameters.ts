import { GraphQLObjectType } from "graphql";

export default function getParameters(o: GraphQLObjectType) {
	const fields = o.getFields();

	return Object.keys(fields).reduce(
		(parameters, field) => ({
			...parameters,
			[field]: fields[field].args.reduce(
				(args, arg) => ({
					...args,
					[arg.name]: arg.type.toString(),
				}),
				Object.create(null),
			),
		}),
		Object.create(null),
	);
}
