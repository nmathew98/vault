import isPathValid from "./is-path-valid";
import { readFile } from "fs/promises";
import { buildClientSchema } from "graphql/utilities";

export default async function buildSchema(
	configuration: Partial<BuildSchemaConfiguration>,
) {
	if (!configuration.path && !configuration.json)
		throw new Error("Either a path or json must be specified!");

	let schema;

	if (configuration.path) {
		const doesFileExist = await isPathValid(configuration.path);

		if (!doesFileExist) throw new Error("Schema not found");

		const buffer = await readFile(configuration.path);
		const json = JSON.parse(`${buffer}`);

		if (!json.data) throw new Error("Invalid schema");

		({ data: schema } = json);
	} else {
		({ data: schema } = configuration.json as Record<string, any>);
	}

	return buildClientSchema(schema.data);
}

interface BuildSchemaConfiguration {
	path: string;
	json: Record<string, any>;
}
